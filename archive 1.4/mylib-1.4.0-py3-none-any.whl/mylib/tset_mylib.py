from mylib import *
import time

print(f"Testing printparams decorator on sample(1,2) and sample(3,3,6)")

@printparams
def sample(i: int, j: int, k=5):
    if i > 1:
        return sample(i - 1, j, k)
    return i + j + k


sample(1, 2)
sample(3, 3, 6)

print(f"credentials('ncs01.case.edu','nbiread')={credentials('ncs01.case.edu', 'nbiread')}")
print('Test strfTime to local time')
now = time.time()
print(f"Now={now}")

for t in [100000, now, 'abc123']:
    print(f"strfTime({t}:{str(type(t))[8:-2]})={strfTime(t)}:{str(type(strfTime(t)))[8:-2]}")
print('\nConvert epochMillis to secs w/ 1 hour offset, and then back to epochMillis')
t = int(now * 1000)
mts = millisToSecs(t, 3600.0)
print(f"millisToSecs({t}, 3600.0)={mts}={strfTime(mts)}")
stm = secsToMillis(mts, 3600.0)
print(f"secsToMillis({mts}, 3600.0)={stm}={strfTime(stm)}")

print(f"\nTest strpSecs's and strfTime's time zone interpretation")
for s in ['2019-09-09T14:00:00.123Z', '2019-09-09T14:00:00.123+0000',
          '2019-09-09T10:00:00.123-0400', '2019-09-09T18:00:00.123+0400']:
    secs = strpSecs(s)
    print(f"{s:28} --> {secs:14.3f} --> local {strfTime(secs)}")

print(f"\nTest strpSecs with date-times around EST to EDT change")
for s in ['2019-11-03T05:00:00.000+0000', '2019-11-03T05:00:00.123Z', '2019-11-03T05:30:00.456Z',
          '2019-11-03T06:00:00.789Z', '2019-11-03T06:30:00.987Z']:
    secs = strpSecs(s)
    print(f"{s:28} --> {secs:14.3f} --> local {strfTime(secs)}")

print('\nTest printIf')
print(f"printIf(True, 'one', 2, [3, 'three'], start='', end='\\n')=", end='')  # multiple args
printIf(1, 'one', 2, [3, 'three'], start='', end='\n')
print(f"printIf(False, 'one', 2, [3, 'three'], start='', end='\\n')=", end='')
printIf(0, 'one', 2, [3, 'three'], start='', end='\n')
print('')
print(f"printIf(True, 'Hello', 'World', start='...', end='!!!\\n')=", end='')
printIf(2, 'Hello', 'World', start='...', end='!!!\n')  # pass-through keyword args
print(f"logErr('Hello World')=", end='')
logErr('Hello World')
if platform.system() == 'Linux':
    print(f"\nlogSubject={logErr.logSubject}")
    print(f"logToAddr={logErr.logToAddr}")

print("\n\nTest loom")


def mapf(item, multby=2):
    return multby * item


def consume(source):
    return [x for x in source]


def consume2(source):
    return [1 / (x - 6) for x in source]


def slow_consume(source):
    for item in source:
        print(item)
        time.sleep(2)


print(f"should return (True, ['aaa', 'bbb', 'ccc', 'ddd', 'eee', 'fff', 'ggg'])")
s = "abcdefg"
result = loom(s, mapf, consume, mapfunc_kwargs={'multby': 3}, mappers=5)
print(f"loom returned {result}")

print(f"\nshould return (False, \"'int' object is not iterable in producer\")")
result = loom(1, mapf, consume)
print(f"loom returned {result}")

print(f"\nshould return (False, \"unsupported operand type(s) for *: 'int' and 'NoneType' in mapf\")")
result = loom([1, 'a', None, 3], mapf, consume)
print(f"loom returned {result}")

print(f"\nshould return (False, ' division by zero in consume2')")
result = loom([1, 2, 3, 4, 5], mapf, consume2)
print(f"loom returned {result}")

print(f"\ntype ctrl-C to test capture of KeyboardInterrupt")
s = "abcdefg"
result = loom(s, mapf, slow_consume, mappers=5)
print(f"loom returned {result}")