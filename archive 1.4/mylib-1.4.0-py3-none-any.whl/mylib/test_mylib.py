#
# Copyright 2020 Dennis Risen, Case Western Reserve University
#
"""pytest testing of mylib.py"""

import pytest
from mylib import *
import random

random.seed(1234567)

def test_dict():
	key_list = [1, 3, 5, 3, 6, 3]
	hist = Dict(1, 0)
	h = {}
	for i in range(len(key_list)):  # single dimensional Dict
		items = hist.items()
		assert items == h.items() 		# single dimensional Dict same as dict()
		assert set([k for k, v in items]) == set(key_list[:i])  # keys in Dict == keys added
		assert len(hist) == len(set(key_list[:i]))
		assert sum([v for k, v in items]) == i
		key = key_list[i]
		hist[key] += 1
		try:
			h[key] += 1
		except KeyError:
			h[key] = 1
