# !/usr/bin/python3
#
# mylib.py is Copyright 2019 Dennis Risen, Case Western Reserve University
#
import calendar
from functools import wraps
from inspect import getfullargspec
import json
import os
import platform
import queue
import re
import sys
from threading import Thread
import time

""" To Do
re-think BucketObj and write testing
"""

class Dict(dict):
	"""Implements a multi-dimensional sparse array of objects with any hashable as a key.

	Undefined items are defined to be the 'zero' object
	"""
	def __init__(self, dim: int = 1, zero: object = 0):
		self.dim = dim
		self.zero = zero
		super().__init__()

	def __missing__(self, key):
		if self.dim == 1:
			if getattr(self.zero, 'copy', None) is None:  # zero has a copy() method?
				x = self.zero			# No, use zero and hope that its a simple object
			else:						# zero object has a copy() method
				x = self.zero.copy() 	# use copy() method to create copy of zero
		else:
			x = Dict(self.dim-1, self.zero)
		super().__setitem__(key, x)
		return x

	# def __setitem__(self, key, value):
	# 	super().__setitem__(key, value)

	def __repr__(self):
		return f"Dict{self.dim}{super().__repr__()}"

	def __str__(self):
		return f"Dict{self.dim}{super().__str__()}"


def anyToSecs(t, offset: float = 0.0) -> float:
	"""Convert milliseconds:int, seconds:float, or ISO datetime:str to seconds:float.
	Parameters:
		t (object):			epoch milliseconds:int, epoch seconds:float, or ISO datetime:str
		offset (float):		add to milliseconds, only
	Returns:
		(float):			epoch seconds
	"""
	if isinstance(t, int):				# epochMillis: int msec?
		return t/1000.0 + offset
	elif isinstance(t, float):			# epochSeconds: float time.time()?
		return t						# no conversion necessary
	elif isinstance(t, str):			# ISO text datetime?
		return strpSecs(t)
	else:
		raise TypeError

def credentials(system: str, username: str = None) -> tuple:
	"""Lookup the (username, password) for [exactly username] on the system.
	Parameters:
		system (str):		system name. E.g. ncs01.case.edu
		username (str):		username on system. Defaults to 1st username on system
	Returns:
		(tuple):			(username: str, password: str)
	"""
	with open(os.path.join(os.path.expanduser('~'), '.credentials.json'),
		'r') as cred_file:
		creds = json.loads(cred_file.read())
	entry = creds.get(system, None)
	if entry is None:					# No user credentials for this system?
		raise KeyError(f"No credentials for {system}")  # Yes. KeyError
	if isinstance(entry, dict) and len(entry) > 0:  # valid entry?
		if username is None: 			# Yes. Any of the username(s) is OK?
			return entry.popitem() 		# return the first (username, password)
		password = entry.get(username, None)  # password for username
		if password is not None: 		# Found password?
			return username, password 	# Yes, return tuple
	raise KeyError(f"Credentials for {system} must be a dict")		# No password for this user

if platform.system() == 'Linux': 		# Running on Linux platform?
	import getpass
	import socket
	import subprocess

	def logErr(*s, start: str = '\n', end: str = '', **kwargs):
		print(f"{start}{strfTime(time.time())} ERROR", *s, end=end, **kwargs)
		message = ' '.join(str(x) for x in s) 	# join the parameters, like print
		try:
			subprocess.run([r'/usr/bin/mailx', '-s', logErr.logSubject]+logErr.logToAddr,
				check=True, input=message.encode())
		except subprocess.CalledProcessError as e:
			print(f"mailx failed: {e}")
	# Default Subject of logError() email messages
	logErr.logSubject = os.path.basename(sys.argv[1]
		if re.search('python', sys.argv[0]) else sys.argv[0])
	# Default list of addressees to receive logError() messages
	logErr.logToAddr = [getpass.getuser() + '@'
		+ '.'.join(socket.getfqdn().split('.')[-2:])]
else:									# No, just print

	def logErr(*s, start: str = '\n', end: str = '', **kwargs):
		print(f"{start}{strfTime(time.time())} ERROR", *s, end=end, **kwargs)

def loom(producer, mapfunc, consumer, mapfunc_kwargs: dict = None,
	consumer_kwargs: dict = None, verbose: int = 0, mappers: int = 1):
	"""
	Parameters:
		producer (iterable)		Source of items to map
		mapfunc (function)		mapfunc(item, **mapfunc_kwargs) is call w/ each item
		consumer (function)		called with iterator of the mapped results from mapfunc
		mapfunc_kwargs (dict)	optional additional keyword arguments to mapfunc
		consumer_kwargs (dict)	optional additional keyword arguments to consumer
		verbose (bool)			True to print performance info
		mappers (int)			number of mapper threads to start
	Results:
		(True, consumer(...))	on successful completion
		(False, error: str)		when there was an exception
	"""

	if mapfunc_kwargs is None:
		mapfunc_kwargs = {}
	if consumer_kwargs is None:
		consumer_kwargs = {}

	def __producer():
		"""
		Iterates the producer, queuing (True,item) to the work_q for each item.
		On exception or exhaustion of the producer, queues exit commands to mappers.
		"""
		nonlocal errmsg, work_q
		try:
			for item in producer: 		# For each item from producer iterable
				if errmsg is not None:  # exception occurred elsewhere. Stop producing.
					break				# stop producing more items
				work_q.put((True, item))  # Queue item for mapfunc to process
		except Exception as e:			# exception other than StopIteration
			errmsg = f"{e} in {getattr(producer, '__name__', 'producer')}"
		for i in range(mappers): 		# tell each mapper to exit
			work_q.put((None, None))

	def __results():
		"""Generator of each item from result_q, while mapper(s) are still active"""
		nonlocal result_q, mapper_cnt, result_cnt
		while mapper_cnt > 0:
			item = result_q.get()
			if item[0]:
				result_cnt += 1
				if verbose and result_cnt % 5000 == 0:
					print(f"{result_cnt} items processed in {time.time()-start_time} seconds")
				yield item[1]
			else:						# a mapper has exited?
				mapper_cnt -= 1			#

	def __mapper():
		nonlocal errmsg, result_q, work_q
		while True:
			item = work_q.get() 		# next item of work
			valid = item[0]
			if valid:					# normal data item?
				try:
					x = mapfunc(item[1], **mapfunc_kwargs)
				except Exception as e:  # exception in mapfunc
					errmsg = f"{e} in {getattr(mapfunc,'__name__','mapfunc')}"
				else:
					result_q.put((True, x))
			else:						# told to exit?
				result_q.put((None, None))  # I'm exiting
				break

	work_q = queue.Queue(maxsize=2*mappers)  # queue from __producer to __mapper
	result_q = queue.Queue(maxsize=2*mappers)  # queue from __mapper to __results
	errmsg = None						# no error, so far
	result_cnt = 0						# number of results returned from mapfunc

	# Start the producer to queue objects to work_q
	t = Thread(name='producer', target=__producer)
	t.start()
	threads = [t]
	start_time = time.time()
	if verbose:
		print(f"mappers starting")

	# Start mappers, which each map input items from work_q to result_q
	for i in range(mappers):
		t = Thread(name='mapper'+str(i), target=__mapper)
		t.start()
		threads.append(t)
	mapper_cnt = mappers 	# the number of mapper exits not yet seen by __results

	# call consumer with results generator
	err = None
	result = None
	try:
		result = consumer(__results(), **consumer_kwargs)
	except KeyboardInterrupt:
		err = 'KeyboardInterrupt'
	except SystemExit:
		err = 'SystemExit'
	except Exception as e:
		err = str(e)
	if err is not None:					# an exception?
		errmsg = f" {err} in {getattr(consumer,'__name__','consumer')}"
	# Consumer and __results have exited.
	# unblock __producer and __mapper if consumer didn't consume all work
	for item in __results():			# Consume any remaining results
		print(f"Consumed leftover {item}")
		pass
	# The producer and mappers have exited, and all work has been consumed
	for t in threads:					# join all of the threads together
		t.join()
	if verbose:
		delta_secs = time.time()-start_time
		print(f"Completed {result_cnt} objects in {delta_secs} seconds.")

	if errmsg is None:
		return True, result
	else:
		return False, errmsg

def millisToSecs(millis: int, time_delta: float = 0) -> float:
	"""Convert CPI server's epochMillis:int to my time.time() equivalent"""
	return millis / 1000.0 + time_delta

def printIf(verbose: int, *s, start: str = '\n', end: str = '', **kwargs):
	if verbose > 0:
		print(f"{start}{strfTime(time.time())}", *s, end=end, **kwargs)

def brief(x, maxlen: int = 20) -> str:		# helper for @printparams
	"""Trim str(any) to maxlen characters plus ellipsis"""
	s = str(x)
	if len(s) < maxlen:
		return s
	else:
		return s[:maxlen]+"..."

indent = 0

def printparams(func):
	"""Decorator that prints function's parameters and result to stderr"""
	names = getfullargspec(func).args

	@wraps(func)
	def decorated(*args, **kwargs):
		global indent
		a = ', '.join(f"{names[i]}:{brief(args[i])}" for i in range(len(args)))
		k = ', '.join(f"{k}:{brief(kwargs[k])}" for k in kwargs)
		print(f"{'  '*indent}{func.__name__}({a + ', ' + k if len(a)>0 and len(k)>0 else a+k})", file=sys.stderr)
		indent += 1
		result = func(*args, **kwargs)
		indent -= 1
		print(f"{'  '*indent}{func.__name__} returned:{brief(result, 60)}", file=sys.stderr)
		return result
	return decorated

def strfTime(t: object, millis: bool = False) -> str:
	"""Format epochMillis:int or epochSeconds:float to localtime str. Pass through str
	Parameters:
		t (object):		epoch milliseconds: int or epoch seconds: float
		millis (bool):	True to include milliseconds in output
	Returns:
		(str):			local time in YYYY-mm-ddTHH:MM:SS[.000]
	"""
	try:
		if isinstance(t, float):
			s = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(t))
			d = t % 1
		elif isinstance(t, int):
			s = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(millisToSecs(t)))
			d = t % 1000/1000.0
		elif isinstance(t, str):
			try:
				secs = strpSecs(t)		# try to convert to local seconds
				s = time.strftime('%Y-%m-%dT%H:%M:%S', time.localtime(secs))
				d = secs % 1
			except ValueError:			# No. Unsuccessful
				return t				# just return the string
		else:
			return str(t)
		if millis:						# output milliseconds too?
			return s + f"{d:.3f}"[1:]
		else:
			return s
	except OSError:						# time.localtime didn't like argument
		return str(t)

def strpSecs(s: str) -> float:
	"""Parse ISO time text to epochSeconds:float."""
	m = re.fullmatch(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(\.[0-9]+)(.*)', s)
	if m is not None:					# an ISO date?
		try:
			zone = m.group(3)
			z = re.fullmatch(r'[+-][0-9]{4}', zone)
			if zone[0] == 'Z':			# Zone is Military Zulu?
				offset = 0
			elif z is not None:			# Zone is +/-HHMM:
				offset = (-60 if zone[0] == '+' else 60)*(int(zone[1:3])*60+int(zone[3:5]))
			else:						# not prepared to parse some other format
				raise ValueError('Zone not military or Zulu')
			# time.strptime doesn't understand zones or fractional seconds
			secs = calendar.timegm(time.strptime(m.group(1), '%Y-%m-%dT%H:%M:%S'))
			if len(m.group(2)) > 0:
				secs += float(m.group(2)) 	# + optional fractional seconds
			return secs+offset
		except ValueError:				# can't think of any specific error
			raise ValueError
	raise ValueError('s does not match ISO format')

def secsToMillis(t: float, time_delta: float = 0.0) -> int:
	"""Convert my time.time():float to CPI server's epochMillis:int."""
	if not isinstance(t, float):
		raise ValueError
	return int((t - time_delta) * 1000.0)

def verbose_1(verbose: int):
	"""Return verbosity level minus 1. E.g. for lower layer
	Parameter:
		verbose (int/bool)	bool or integer verbosity level
	Returns:
		bool input or verbose-1
	"""
	if isinstance(verbose, bool): 		# bool
		return 1 if verbose else 0 		# convert to int
	elif isinstance(verbose, int): 		# int is decremented
		return verbose-1 if verbose > 0 else 0
	else:								# other input
		raise ValueError(f"type={type(verbose)}")
