from .mylib import anyToSecs, credentials, Dict, logErr,\
	loom, millisToSecs, printIf, printparams, strfTime, strpSecs, secsToMillis, verbose_1