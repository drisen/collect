#! /usr/bin/python3
#
# cpiTables.py is Copyright 2019 by Dennis Risen, Case Western Reserve University
#
# if __name__ == '__main__':
# 	from cpitable import Table, report_type_uses, domainGenerator, neighborGenerator, real_timeGen
# else:
from .cpitable import Table, find_table, report_type_uses
from .cpitable import neighborGenerator, real_timeCS, real_timeGen

def add_table(tables: dict, table: Table):
	"""Add a Table to the dictionary

	Parameters:
		tables (dict):	the dictionary to add to
		table (Table)	the Table to add
	"""
	if table.tableName in tables:
		tables[table.tableName].append(table)
	else:
		tables[table.tableName] = [table]

# quantities to estimate record volume
MINUTE = 60.0						# seconds in a minute
HOUR = 60*MINUTE					# seconds in an hour
DAY = 24*HOUR						# seconds in a day

NUMAP = 4900			# number of APs
NUMBLD = 145			# number of buildings
NUMCTL = 16				# number of controllers
NUMDOM = 4				# number of domains
NUMDEV = 32				# number of devices
NUMFLOOR = 4			# avg number of floors/building
NUMSSID = 8				# avg number of SSID with data
NUMVIRT = 3				# number of virtual domains
# number of records/hour in the composite Historical* tables
NUMHIST = ((NUMAP+1)*(NUMSSID+1+2) + 2*NUMDEV*(NUMSSID+1+1) + 2*NUMDEV
+ (NUMBLD*NUMFLOOR)*(NUMSSID+1) + (NUMSSID+1+2)*NUMDOM + NUMVIRT*(7*NUMDOM)
)
SAMPERHR = 60/5			# samples/hour in HistoricalClient[Counts|Traffics]

archive = dict()					# dict of archived table definitions
production = dict()					# dict of production tables to collect
real_time = dict()					# dict of production tables to collect real-time
test = dict()						# dict of table definitions for unit testing
all_table_dicts = [production, real_time, archive, test]  # all known tables

# Poll daily shortly after midnight
# Each poll takes less than 3 minutes. Most are just a few seconds.
offset = 5*60.0		# first daily poll starts at 0+5=5 minutes after midnight

add_table(production, Table("v4", "data", "AccessPointDetails", True, 8*HOUR, NUMAP,
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),  # dupl the @id uncommented 2018-07-01
	("ApAdminStatusEnum", "adminStatus"),
	("String", "apType"), 			# AP type
	# Ignore, because we don't/won't have any autonomous APs
	("String", "autonomousAP_description", False),  # SNMP sysDescr
	("boolean", "autonomousAP_reachable", False),  # SNMP reachable
	("String", "autonomousAP_sysLocation", False),  # SNMP sysLocation
	("String", "autonomousAP_sysObjectId", False),  # SNMP sysObjectId
	("boolean", "autonomousAP_wgbStatus", False),  # is the AP in WGB mode?
	("int", "clientCount"), 		# doc fixed string-->int in v4
	("int", "clientCount_2_4GHz"),  # doc fixed string-->int in v4
	("int", "clientCount_5GHz"),
	('float', 'coordinates_XCoordinate'),		# x coordinate in feet
	('float', 'coordinates_YCoordinate'),		# y coordinate in feet
	('float', 'coordinates_ZCoordinate'),		# z coordinate in feet
	("String", "ethernetMac_octets"),  # AP MAC
	# ("String", "instanceUuid"), 	# blank. removed in v1
	("String", "ipAddress_address"),  # AP IP address
	("String", "locationHierarchy"),  # renamed from locationHeirarchy in v3
	("String", "macAddress_octets"),  # base radio MAC
	("String", "mapLocation"), 		# SNMP location
	("String", "model"), 			# AP model
	("String", "name"), 			# AP name
	("ReachabilityStateEnum", "reachabilityStatus"),  # [not present]
	("String", "serialNumber"),
	("long", "serviceDomainId"),
	("String", "softwareVersion"),
	("AlarmSeverityEnum", "status"),
	("String", "type"),
	# have yet to see a populated unifiededApInfo
	# ("int", "unifiedApInfo_instanceId"), 	# removed from all doc in v3
	# ("long", "unifiedApInfo_instanceVersion"), 	# removed from all doc in v3
	("int", "unifiedApInfo_apCertType"),
	("String", "unifiedApInfo_apGroupName"),  # AP group this AP is assigned to
	("MonitorOnlyModeEnum", "unifiedApInfo_apMode"),  # doc as String but NUMBER through v2
	("int", "unifiedApInfo_apStaticEnabled"),
	("String", "unifiedApInfo_bootVersion"),  # Boot version
	("long", "unifiedApInfo_capwapJoinTakenTime"),  # 1/100ths to join CAPWAP
	("long", "unifiedApInfo_capwapUpTime"),  # 1/100ths since AP joined controller
	("String", "unifiedApInfo_controllerIpAddress"),
	("String", "unifiedApInfo_controllerName"),
	("String", "unifiedApInfo_contryCode"),  # 3-letter. misspelled in doc too
	("boolean", "unifiedApInfo_encryptionEnabled"),
	("String", "unifiedApInfo_flexConnectGroupName", False),  # [not present]
	("boolean", "unifiedApInfo_flexConnectMode"),
	("String", "unifiedApInfo_iosVersion"),
	("Date", "unifiedApInfo_lastAssociatedTime"),  # added vn ISO string
	("Date", "unifiedApInfo_lastDissociatedTime"),  # added vn ISO string
	("boolean", "unifiedApInfo_linkLatencyEnabled"),
	("MeshRoleEnum", "unifiedApInfo_lradMeshNode_meshRole"),  # added vn
	("boolean", "unifiedApInfo_maintenanceMode"),  # in maintenance mode?
	("PoeStatusEnum", "unifiedApInfo_poeStatusEnum"),  # [not present]
	("int", "unifiedApInfo_portNumber"),
	("int", "unifiedApInfo_powerInjectorState"),
	("int", "unifiedApInfo_preStandardState"),
	("String", "unifiedApInfo_primaryMwar"),
	("boolean", "unifiedApInfo_rogueDetectionEnabled"),
	("String", "unifiedApInfo_secondaryMwar"),
	("boolean", "unifiedApInfo_sshEnabled"),
	("int", "unifiedApInfo_statisticsTimer"),  # Stats interval in secs, or 0
	("String", "unifiedApInfo_taginfo_policyTagName", False),
	("String", "unifiedApInfo_taginfo_rfTagName", False),
	("String", "unifiedApInfo_taginfo_siteTagName", False),
	("UnifiedApTagSourceEnum", "unifiedApInfo_taginfo_tagSource", False),
	("boolean", "unifiedApInfo_telnetEnabled"),
	("String", "unifiedApInfo_tertiaryMwar"),
	("boolean", "unifiedApInfo_vlanEnabled", False),  # not present-- no FlexConnect
	("int", "unifiedApInfo_vlanNativeId", False),
	("boolean", "unifiedApInfo_WIPSEnabled"),
	("long", "upTime"),  				# AP up time in 1/100ths
	)
	# entry per CDP neighbor
	.subTable("cdpNeighbors", [("float", "polledTime"), ("long", "@id")],
		("String", "capabilities"),
		("String", "duplex"),			# Port mode {Half Duplex, Full Duplex}??
		("String", "interfaceSpeed"), 	# {10Mbps, 100Mbps, 1Gbps, 10Gbps, Auto}??
		("String", "localPort"),		# local port number
		("String", "neighborIpAddress_address"),
		("String", "neighborName"),		# neighbor Device Name
		("String", "neighborPort"),		# neighbor port number
		("String", "platform")
	)
	.subTable("reapApVlanAclMappings", [("float", "polledTime"), ("long", "@id")],
		("String", "reapEgressAcl", False),  # Egress ACL name for vlan-ACL mapping
		("String", "reapIngressAcl", False),  # Ingress ACL name for vlan-ACL mapping
		("int", "realVlanId", False) 	# VLAN ID mapped to the ACL for this AP
	)
	# array appeared after 2017-02-16 software upgrade
	.subTable('unifiedApInfo_wlanProfiles', [("float", "polledTime"), ("long", "@id")],
		("boolean", "broadcastSsidEnabled"),
		("String", "profileName"),
		("String", "ssid")
	)
	.subTable("unifiedApInfo_wlanVlanMappings", [("float", "polledTime"), ("long", "@id")],
		("String", "ssid", False),		# WLAN SSID
		("int", "vlanId", False),		# VLAN id
		("int", "wlanId", False),		# WLAN id
	)
	.set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Poll daily for details e.g {ccx*} not in ClientSessions or HistoricalClient*
offset += 5*60.0
# One record for each client seen per updateTime within the last week
add_table(production, Table("v4", "data", "ClientDetails", True, DAY+offset, 60000,
	("long", "@id"), 					# release 3.x changed string-->long
	("String", "@displayName", None), 	# dupl the @id uncommented 2018-07-01
	("String", "adDomainName", False),  # AD domain acquired from ISE
	("String", "apIpAddress_address"),  # associated AP IP address
	("String", "apMacAddress_octets"),  # associated AP MAC address
	("String", "apName"), 				# associated AP name
	("int", "apSlotId"), 				# associated AP slot ID
	("epochMillis", "associationTime"),  # current or last session start
	("String", "auditSessionId", False),  # Client audit session ID
	("AuthenticationAlgorithmEnum", "authenticationAlgorithm"),  # client's auth.
	("String", "authnTimeStamp", False),  # acquired from ISE
	("String", "authorizationPolicy", False),  # acquired from ISE
	("String", "authorizedBy", False),  # Authorization provider
	# ("long", "bytesReceived"),		# only present in v1
	# ("long", "bytesSent"),   			# only present in v1
	("CcxFSVersionEnum", "ccxFSVersion"),  # client card version
	("CcxFSVersionEnum", "ccxLSVersion"),  # client card version
	("CcxFSVersionEnum", "ccxMSVersion"),  # client card version
	("CcxFSVersionEnum", "ccxVSVersion"),  # client card version
	("CCXVersionEnum", "ccxVersion"), 	# client card version
	("ClientAclAppliedEnum", "clientAaaOverrideAclApplied"),  # override applied?
	("String", "clientAaaOverrideAclName", False),  # ACL name
	("ClientAclAppliedEnum", "clientAclApplied"),  # ACL applied to client
	("String", "clientAclName", False),  # ACL name applied to the client
	("ClientApModeEnum", "clientApMode"),
	("String", "clientInterface"), 		# interface LAN
	("String", "clientRedirectUrl", False),  # Redirect URL applied to the client
	("ConnectionTypeEnum", "connectionType"),  # from ISE
	("String", "ctsSecurityGroup", False),
	("String", "deviceIpAddress_address"),  # of associated controller or switch
	("String", "deviceName"), 			# name of associated controller or switch
	("String", "deviceType"), 			# Client device type acquired from ISE
	("EapTypeEnum", "eapType"),
	("EncryptionCypherEnum", "encryptionCypher"),  # Client encrpyt. cypher
	("String", "failureCode", False), 	# from ISE
	("String", "failureStep", False), 	# from ISE
	("epochMillis", "firstSeenTime"), 	# time when client was first discovered
	("String", "hostname", False), 		# reverse DNS from client IP address
	("HreapAuthenticationEnum", "hreapLocallyAuthenticated"),  # auth via HREAP?
	("String", "ifDescr", False), 		# SNMP ifDescr of the connected switch
	("int", "ifIndex"),  # SNMP ifIndex of the connected switch
	# ("String", "instanceUUid"),		# not in the doc., but present in v2.
	("String", "ipAddress_address"), 	# Client IP address
	("ClientIpTypeEnum", "ipType"), 	# Client IP type
	("String", "iseName", False), 		# ISE name which the client is reported
	("String", "location"), 			# Map location hierarchy
	("String", "macAddress_octets"), 	# Client MAC address
	("MobilityStatusEnum", "mobilityStatus"),  # Client mobility status
	("NACStateEnum", "nacState"), 		# Client NAC state
	# ("long", "packetsReceived"), 		# only in v1
	# ("long", "packetsSent"),			# only in v1
	("SecurityPolicyEnum", "policyType"),  # v2
	("PolicyTypeStatusEnum", "policyTypeStatus"),  # Client from ISE
	("PostureStatusEnum", "postureStatus"),  # Client from ISE
	("ClientProtocolEnum", "protocol"),  # [last] connection protocol
	("String", "radiusResponse", False),  # from ISE
	# ("int", "rssi"),					# only in v1
	("SecurityPolicyStatusEnum", "securityPolicyStatus"),  # Client on network?
	# ("int", "snr"),					# only in v1
	("ClientSpeedEnum", "speed"),  		# wired port speed or UNKNOWN for wireless
	("String", "ssid"),  				# [last] SSID
	("ClientStatusEnum", "status"), 	# Client connection
	# ("double", "throughput"),			# only in v1
	# ("long", "traffic"),				# only in v1
	("epochMillis", "updateTime"), 		# time this record was last updated
	("String", "userName"), 			# Client username
	("String", "vendor"), 		# Vendor name of the client NIC from OUI mapping
	("int", "vlan"),  # VLAN ID. JSON is NUMBER. Doc corrected string-->int in v4
	("String", "vlanName", False), 		# [blank] that client is connected to
	("WebSecurityEnum", "webSecurity"),  # client is authenticated by WebAuth
	("WepStateEnum", "wepState"),
	("String", "wgbMacAddress_octets"),  # if client s a WorkGroup Bridge
	("WGBStatusEnum", "wgbStatus"), 	# Client WorkGroup Bridge status
	("WiredClientTypeEnum", "wiredClientType")
	)
	.subTable("clientAddresses", [("float", "polledTime"), ("long", "@id")],
		("ClientIpAddressAssignmentType", "assignmentType", False),
		("Date", "discoverTime", False), 	# client discovery time
		("String", "ipAddress_address", False),
		("ClientIpAddressScope", "ipAddressScope", False),
		("String", "macAddress_octets", False)
	)
	.set_id_field("@id")
	.set_time_field('updateTime')
#	.set_generator(real_timeGen)
	.set_query_options({".full": "true", ".nocount": "true"})
)

# One record for each client seen per updateTime within the last week
# ClientSessionsDetails uses this table as a template
add_table(archive, Table("v4", "data", "ClientDetails", True, 4*60, 60000,
	("long", "@id"), 					# release 3.x changed string-->long
	("String", "@displayName", None), 	# dupl the @id uncommented 2018-07-01
	("String", "adDomainName", False),  # AD domain acquired from ISE
	("String", "apIpAddress_address", False),  # associated AP IP address
	("String", "apMacAddress_octets"),  # associated AP MAC address
	("String", "apName"), 				# associated AP name
	("int", "apSlotId"), 				# associated AP slot ID
	("epochMillis", "associationTime"),  # current or last session start
	("String", "auditSessionId", False),  # Client audit session ID
	("AuthenticationAlgorithmEnum", "authenticationAlgorithm"),  # client's auth.
	("String", "authnTimeStamp", False),  # acquired from ISE
	("String", "authorizationPolicy", False),  # acquired from ISE
	("String", "authorizedBy", False),  # Authorization provider
	# ("long", "bytesReceived"),		# only present in v1
	# ("long", "bytesSent"),   			# only present in v1
	("CcxFSVersionEnum", "ccxFSVersion", False),  # client card version
	("CcxFSVersionEnum", "ccxLSVersion", False),  # client card version
	("CcxFSVersionEnum", "ccxMSVersion", False),  # client card version
	("CcxFSVersionEnum", "ccxVSVersion", False),  # client card version
	("CCXVersionEnum", "ccxVersion", False), 	# client card version
	("ClientAclAppliedEnum", "clientAaaOverrideAclApplied", False),  # override applied?
	("String", "clientAaaOverrideAclName", False),  # ACL name
	("ClientAclAppliedEnum", "clientAclApplied"),  # ACL applied to client
	("String", "clientAclName", False),  # ACL name applied to the client
	("ClientApModeEnum", "clientApMode"),
	("String", "clientInterface"), 		# interface LAN
	("String", "clientRedirectUrl", False),  # Redirect URL applied to the client
	("ConnectionTypeEnum", "connectionType"),  # from ISE
	("String", "ctsSecurityGroup", False),
	("String", "deviceIpAddress_address", False),  # of associated controller or switch
	("String", "deviceName", False), 			# name of associated controller or switch
	("String", "deviceType"), 			# Client device type acquired from ISE
	("EapTypeEnum", "eapType"),
	("EncryptionCypherEnum", "encryptionCypher"),  # Client encrpyt. cypher
	("String", "failureCode", False), 	# from ISE
	("String", "failureStep", False), 	# from ISE
	("epochMillis", "firstSeenTime", False), 	# time when client was first discovered
	("String", "hostname", False), 		# reverse DNS from client IP address
	("HreapAuthenticationEnum", "hreapLocallyAuthenticated"),  # auth via HREAP?
	("String", "ifDescr", False), 		# SNMP ifDescr of the connected switch
	("int", "ifIndex", False),  # SNMP ifIndex of the connected switch
	# ("String", "instanceUUid"),		# not in the doc., but present in v2.
	("String", "ipAddress_address"), 	# Client IP address
	("ClientIpTypeEnum", "ipType"), 	# Client IP type
	("String", "iseName", False), 		# ISE name which the client is reported
	("String", "location", False), 			# Map location hierarchy
	("String", "macAddress_octets"), 	# Client MAC address
	("MobilityStatusEnum", "mobilityStatus"),  # Client mobility status
	("NACStateEnum", "nacState"), 		# Client NAC state
	# ("long", "packetsReceived"), 		# only in v1
	# ("long", "packetsSent"),			# only in v1
	("SecurityPolicyEnum", "policyType"),  # v2
	("PolicyTypeStatusEnum", "policyTypeStatus"),  # Client from ISE
	("PostureStatusEnum", "postureStatus"),  # Client from ISE
	("ClientProtocolEnum", "protocol"),  # [last] connection protocol
	("String", "radiusResponse", False),  # from ISE
	# ("int", "rssi"),					# only in v1
	("SecurityPolicyStatusEnum", "securityPolicyStatus"),  # Client on network?
	# ("int", "snr"),					# only in v1
	("ClientSpeedEnum", "speed", False),  		# wired port speed or UNKNOWN for wireless
	("String", "ssid"),  				# [last] SSID
	("ClientStatusEnum", "status"), 	# Client connection
	# ("double", "throughput"),			# only in v1
	# ("long", "traffic"),				# only in v1
	("epochMillis", "updateTime"), 		# time this record was last updated
	("String", "userName"), 			# Client username
	("String", "vendor", False), 		# Vendor name of the client NIC from OUI mapping
	("int", "vlan"),  # VLAN ID. JSON is NUMBER. Doc corrected string-->int in v4
	("String", "vlanName", False), 		# [blank] that client is connected to
	("WebSecurityEnum", "webSecurity"),  # client is authenticated by WebAuth
	("WepStateEnum", "wepState"),
	("String", "wgbMacAddress_octets", False),  # if client s a WorkGroup Bridge
	("WGBStatusEnum", "wgbStatus", False), 	# Client WorkGroup Bridge status
	("WiredClientTypeEnum", "wiredClientType", False)
	)
	.subTable("clientAddresses", [("float", "polledTime"), ("long", "@id")],
		("ClientIpAddressAssignmentType", "assignmentType", False),
		("Date", "discoverTime", False), 	# client discovery time
		("String", "ipAddress_address", False),
		("ClientIpAddressScope", "ipAddressScope", False),
		("String", "macAddress_octets", False)
	)
	.set_id_field("@id")
	.set_time_field('updateTime')
	.set_query_options({".full": "true", ".nocount": "true"})
)


""" This view is SELECT CS.*, CD,.apSlotId, CD.updateTime from ClientSessions CS, ClientDetails, CD
where CS.macAddress_octets=CD.macAddress_octets and CS.sessionStartTime=CD.associationTime.
It verifies equality in other matching fields and reports suspect matches and failure to match.
"""
add_table(real_time, Table("v4", "data", "ClientSessionsDetails", True, 298, 17000,
	("long", "@id"), 					# release 3.x changed string-->long
	("String", "@displayName", None), 	# copy of @id
	("String", "adDomainName", None), 	# from ISE; missing in v2 and v4
	("String", "anchorIpAddress_address", None),  # of the mobility anchor, or 0.0.0.0
	# ("String", "apIpAddress"),		# doc but blank in v1. removed in v3
	("String", "apMacAddress_octets"), 	# MAC of associated AP
	# ("String", "apName"),			# was blank in v1. removed in v3
	("int", "apSlotId"), 				# associated AP slot ID (from ClientDetails)
	("AuthenticationAlgorithmEnum", "authenticationAlgorithm", None),  # Client alg
	("String", "authorizationPolicy", None),  # from ISE; missing in v1 and v4
	("long", "bytesReceived"), 		# bytes received [so far] during the session
	("long", "bytesSent"), 			# bytes sent [so far] during the session
	("String", "clientInterface", None),  # {case[auth|guest]*, ic-inside, management}
	("ConnectionTypeEnum", "connectionType", None),
	("String", "ctsSecurityGroup", None),  # from ISE; missing in v2 and v4
	("String", "deviceMgmtAddress_address", None),  # controller. v3 changed string deviceIpAddress --> InetAddress
	("String", "deviceName", None), 	# controller or switch name
	("EapTypeEnum", "eapType", None),
	("EncryptionCypherEnum", "encryptionCypher", None),  # Client cypher
	# ("String", "instanceUuid"),		# originally doc, but removed in v1
	("String", "ipAddress_address", None),  # Client. string in v1, InetAddress in v3
	("ClientIpTypeEnum", "ipType", None),
	("String", "location", None), 		# AP or switch Map: campus > building > floor
	("String", "macAddress_octets"), 	# Client MAC
	("long", "packetsReceived"), 		# number received [so far] in the session
	("long", "packetsSent"), 			# number sent [so far] in the session
	("PolicyTypeStatusEnum", "policyTypeStatus", None),  # Client policy
	("ClientSpeedEnum", "portSpeed", None),  # Speed for wired or UNKNOWN for wireless
	("PostureStatusEnum", "postureStatus", None),  # Client posture from ISE
	("String", "profileName"), 			# WLAN Profile Name
	("ClientProtocolEnum", "protocol"),
	("String", "roamReason", None), 	# missing in v1 and v4
	("int", "rssi"), 					# dBm from last polling in the session
	("SecurityPolicyEnum", "securityPolicy", None),  # Client policy
	("epochMillis", "sessionEndTime"), 	# session end time; or far future time
	("epochMillis", "sessionStartTime"),
	("int", "snr"), 					# Signal to Noise Ratio from last polling
	("String", "ssid"), 				# SSID
	("double", "throughput", None), 	# Session avg. blank while session open
	("epochMillis", "updateTime"), 		# time this record was last updated (from ClientDetails)
	("String", "userName"), 			# Client username
	("int", "vlan", False), 			# vlan name. was string before v3
	("WebSecurityEnum", "webSecurity", None),  # is Client auth via WebAuth?
	("String", "wgbMacAddress_octets", None),  # WorkGroup Bridge MAC or "00:00:00:00:00:00:00"
	("WGBStatusEnum", "wgbStatus", None), 	# Client type
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
	.set_generator(real_timeCS)
)

''' One record per session that ended in the past 4 weeks or is currently active
The system regularly updates the data in each active session. When a
session is active, its sessionEndTime is set to a time far in the future.
Once a session is closed, the record is frozen, with its actual sessionEndTime.
'''
add_table(production, Table("v4", "data", "ClientSessions", False, 21*HOUR, 17000,
	("long", "@id"), 					# release 3.x changed string-->long
	("String", "@displayName", None), 	# copy of @id
	("String", "adDomainName", False), 	# from ISE; missing in v2 and v4
	("String", "anchorIpAddress_address"),  # of the mobility anchor, or 0.0.0.0
	# ("String", "apIpAddress"),		# doc but blank in v1. removed in v3
	("String", "apMacAddress_octets"), 	# MAC of associated AP
	# ("String", "apName"),			# was blank in v1. removed in v3
	("AuthenticationAlgorithmEnum", "authenticationAlgorithm"),  # Client alg
	("String", "authorizationPolicy", False),  # from ISE; missing in v1 and v4
	("long", "bytesReceived"), 		# bytes received [so far] during the session
	("long", "bytesSent"), 			# bytes sent [so far] during the session
	("String", "clientInterface"),  # {case[auth|guest]*, ic-inside, management}
	("ConnectionTypeEnum", "connectionType"),
	("String", "ctsSecurityGroup", False),  # from ISE; missing in v2 and v4
	("String", "deviceMgmtAddress_address"),  # controller. v3 changed string deviceIpAddress --> InetAddress
	("String", "deviceName"), 			# controller or switch name
	("EapTypeEnum", "eapType"),
	("EncryptionCypherEnum", "encryptionCypher"),  # Client cypher
	# ("String", "instanceUuid"),		# originally doc, but removed in v1
	("String", "ipAddress_address"), 	# Client. string in v1, InetAddress in v3
	("ClientIpTypeEnum", "ipType"),
	("String", "location"), 			# AP or switch Map: campus > building > floor
	("String", "macAddress_octets"), 	# Client MAC
	("long", "packetsReceived"), 		# number received [so far] in the session
	("long", "packetsSent"), 			# number sent [so far] in the session
	("PolicyTypeStatusEnum", "policyTypeStatus"),  # Client policy
	("ClientSpeedEnum", "portSpeed"), 	# Speed for wired or UNKNOWN for wireless
	("PostureStatusEnum", "postureStatus"),  # Client posture from ISE
	("String", "profileName"), 			# WLAN Profile Name
	("ClientProtocolEnum", "protocol"),
	("String", "roamReason", False), 	# missing in v1 and v4
	("int", "rssi"), 					# dBm from last polling in the session
	("SecurityPolicyEnum", "securityPolicy"),  # Client policy
	("epochMillis", "sessionEndTime"), 	# session end time; or far future time
	# only in rare cases is the sessionEndTime not synchronized to the 5-minute polling
	("epochMillis", "sessionStartTime"),
	("int", "snr"), 					# Signal to Noise Ratio from last polling
	("String", "ssid"), 				# SSID
	("double", "throughput"), 			# Session avg. blank while session open
	("String", "userName"), 			# Client username
	("int", "vlan"), 					# vlan name. was string before v3
	("WebSecurityEnum", "webSecurity"),  # is Client auth via WebAuth?
	("String", "wgbMacAddress_octets"),  # WorkGroup Bridge MAC or "00:00:00:00:00:00:00"
	("WGBStatusEnum", "wgbStatus"), 	# Client type
	).set_id_field("@id").set_time_field("sessionStartTime").set_rollup(28 * DAY)
	.set_query_options({".full": "true", ".nocount": "true"})
	.set_pager('cs_pager')
)

offset += 5*60.0
# One record for each device
add_table(production, Table("v4", "data", "Devices", True, DAY+offset, NUMDEV,
	("long", "@id"), 				# release 3.x changed string-->long
	# DETERMINE WHICH ID CORRELATES TO OTHER IDS FOR THESE DEVICES
	("String", "@displayName", None), 	# duplicates @id
	("DeviceAdminStatusEnum", "adminStatus"),  # 2017-02-16 upgrade added string; -->enum in v4
	# ("int", "clearedAlarms"),		# removed in v3
	("String", "collectionDetail"),  # detailed status of inventory collection
	("InventoryCollectionStatusEnum", "collectionStatus"),  # last status
	("Date", "collectionTime"), 	# Instant. Time of collection
	("Date", "creationTime"), 		# Instant. Time when the device was created
	# ("int", "criticalAlarms"),	# removed in v3
	("long", "deviceId"), 			# management net element assoc w/ device
	("String", "deviceName"), 		# name of the device
	("String", "deviceType"), 		# Type of device
	# ("int", "informationAlarms"),	# removed in v3
	# ("String", "instanceUuid"),	# originally doc. removed in v1
	("String", "ipAddress"), 		# preferred management access IP address
	("String", "location"), 		# system location
	# ("int", "majorAlarms"),		# removed in v3
	("LifecycleStateEnum", "managementStatus"),  #
	("List", "manufacturerPartNrs"),
	# ("int", "minorAlarms"),		# removed in v3
	("String", "productFamily"),
	("ReachabilityStateEnum", "reachability"),
	("String", "softwareType"),
	("String", "softwareVersion"),
	# ("int", "warningAlarms"),		# removed in v3
	)
	# .subTable("manufacturerPartNrs", [("float", "polledTime"), ("long", "@id")],	# Array added in v3.
	# ("String", "partNumber")
	# )
	.set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# data is deleted after 2 months
add_table(production, Table("v4", "data", "Events", False, 2*DAY + 5*HOUR/2, 2300,
	("long", "@id", None), 			# release 3.x changed string-->long
	("String", "@displayName", None),  # duplicates eventId uncommented 2018-07-01
	# ("String", "@uuid"),			# originally doc, but not present in v1
	("int", "category_ordinal"), 	# major cat index. undoc in v3
	("String", "category_value"),  # major cat text. silently renamed from category in v3
	# ("String", "category"),		# major cat. enum in documentation, but not in output
	("int", "condition_ordinal"), 	# occurrence type index within major cat. undoc in v3
	("String", "condition_value"),  # occurrence type within major cat. undoc in v3
	# ("String", "condition"),		# occurrence type. enum in doc, but incorrect
	("long", "correlated"), 		# The alarm ID correlated for this event
	("String", "description"), 		# free text description of the event/alarm
	("String", "deviceName"), 	# reporting entity. E.g. AP apName, Interface 802.11b/g/n
	("Date", "deviceTimeStamp", False),  # optional time when event occurred
	("Date", "eventFoundAt"), 		# time when the event was found
	("long", "eventId"), 			# release 3.x changed string-->long
	# ("String", "instanceUuid"),	# originally doc, but not found in v1
	("AlarmSeverityEnum", "severity"),
	("String", "source"), 			# entity about which the event/alarm is reported
	# typically of the form [LradIf!apMac!slotId|UnifiedAp!apMac]
	("Date", "timeStamp"), 			# time of event, or if not avail. record creation
	).set_id_field("eventId").set_time_field("eventFoundAt")
		.set_query_options({".full": "true", ".nocount": "true"})
		.set_rollup(61 * DAY)  # Events are apparently kept for 2 months
		)

# For navigating Groups. Defines three trees of groups.
# One each for {User Defined, Device Type, Location}
offset += 5*60.0
add_table(production, Table("v2", "data", "GroupSpecification", True, DAY+offset, 800,
	("long", "@id"), 				# id of this group. release 3.x changed string-->long
	("String", "@displayName", None),  # dupl groupName. uncommented 2018-07-01
	("String", "description"), 		# Description of the group
	("String", "groupName"), 		# name of the group
	("String", "groupPath"), 		# full hierarchy path of the group
	# ("String", "instanceUuid"),	# doc but not present in v1. removed in v2
	("long", "parentId") 			# id of parent or -1 if a root group
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Posted every 5 minutes. Records deleted after 24 hours.
add_table(production, Table("v4", "data", "HistoricalClientCounts", False, 3*HOUR, int(NUMHIST*SAMPERHR),
	("long", "@id"), 				# release 3.x changed from string-->long
	("String", "@displayName", None),  # copy of @id uncommented 2018-07-01
	("int", "authCount"), 			# as of last collection time
	("epochMillis", "collectionTime"),  # time when record was collected
	("int", "count"), 				# total client count
	("int", "dot11aAuthCount"),
	("int", "dot11aCount"),
	("int", "dot11acAuthCount"),
	("int", "dot11acCount"),
	("int", "dot11ax2_4AuthCount"),
	("int", "dot11ax2_4Count"),
	("int", "dot11ax5AuthCount"),
	("int", "dot11ax5Count"),
	("int", "dot11bAuthCount"),
	("int", "dot11bCount"),
	("int", "dot11gAuthCount"),
	("int", "dot11gCount"),
	("int", "dot11n2_4AuthCount"),
	("int", "dot11n2_4Count"),
	("int", "dot11n5AuthCount"),
	("int", "dot11n5Count"),
	# ("String", "instanceUuid"),	# originally doc, but removed from v1
	("String", "key"),
	("String", "subkey"),
	# for type=ACCESSPOINT; subkey is {"All", enum(SSIDs)}; key is an apMac
	# for type=DEVICE; subkey is {"All", enum(SSIDs)}; key is controller Ip
	# for type=MAPLOCATION; subkey is {"All", enum(SSIDs)}; key is a GroupSpecification.groupName
	# data is useless because e.g. "Floor 1" is repeated w/o qualification
	# for type=SSID; subkey is {virtual domain, "ROOT-DOMAIN"}; key is {"All SSIDs", enum(SSIDs)}
	# subkeys repeat multiple times. all data=0 except for ROOT-DOMAIN
	# for type=VIRTUALDOMAIN; subkey is All; key is virtualDomain - [All Autonomous APs|All SSIDs|All wired|All Wireless]
	# similarly, the keys repeat multiple times, and all data=0 except for ROOT-DOMAIN - [|All Wireless|All SSIDs]
	("ClientCountTypeEnum", "type"),
	("int", "wgbAuthCount"), 		# authenticated as WGB or wired guest
	("int", "wgbCount"), 			# connected as WorkGroup Bridge or wired guest
	("int", "wired100MAuthCount"),
	("int", "wired100MCount"),
	("int", "wired10GAuthCount"), 	# appeared in 3.6
	("int", "wired10GCount"), 		# appeared in 3.6
	("int", "wired10MAuthCount"),
	("int", "wired10MCount"),
	("int", "wired1GAuthCount"),
	("int", "wired1GCount")
	# ("String", "adminStatus")	# undoc. appeared in 2017-02-16, then undoc
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Cumulative (bytes, packets) x (sent, received, dropped|retries) by client MAC
# Active sessions posted every 15 minutes. Deleted after 24 hours
# statistics are during this session
add_table(production, Table("v4", "data", "HistoricalClientStats", False, 6*HOUR, 36000,
	("long", "@id"), 				# Session id. release 3.x changed string-->long
	("String", "@displayName", None),  # copy of @id uncommented 2018-07-01
	("long", "bytesReceived"), 		# cumulative bytes received
	("long", "bytesSent"), 			# cumulative bytes sent
	("epochMillis", "collectionTime"),  # Unix epoch millis
	("float", "dataRate"), 			# reading data rate Mbps
	("long", "dataRetries"), 		# cumulative data Retries
	# ("String", "instanceUuid"),	# originally doc. removed in v1
	("String", "macAddress_octets"),  # client MAC
	("long", "packetsReceived"), 	# cumulative packets received
	("long", "packetsSent"), 		# cumulative packets Sent
	("long", "raPacketsDropped"), 	# cumulative IPv6 RA packets dropped
	("int", "rssi"), 				# RSSI (dBm) as measured by AP
	("long", "rtsRetries"), 		# cumulative RTS Retries
	("long", "rxBytesDropped"), 	# cumulative rx Bytes dropped
	("long", "rxPacketsDropped"), 	# cumulative rx Packets dropped
	("int", "snr"), 				# SNR as measured by the AP
	("long", "txBytesDropped"), 	# cumulative tx Bytes dropped
	("long", "txPacketsDropped") 	# cumulative tx Packets dropped
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Cumulative (Received,Sent,Throughput) x (a,ac,d,g,n2.4,5,...) by element[Key+Type]
# Posted every 15 minutes
add_table(production, Table("v4", "data", "HistoricalClientTraffics", False, 3*HOUR, int(NUMHIST*SAMPERHR),
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),  # copy of @id uncommented 2018-07-01
	# ("String", "@uuid"),			# removed from documentation in v1+
	("epochMillis", "collectionTime"),
	("long", "dot11aReceived"), 	# cumulative bytes received
	("long", "dot11aSent"), 		# cumulative bytes sent
	("long", "dot11aThroughput"), 	# cumulative throughput in Kbps
	("long", "dot11acReceived"), 	# cumulative bytes received
	("long", "dot11acSent"), 		# cumulative bytes sent
	("long", "dot11acThroughput"),  # total throughput in Kbps
	("long", "dot11ax2_4Received"),  # cumulative bytes received
	("long", "dot11ax2_4Sent"), 	# cumulative bytes sent
	("long", "dot11ax2_4Throughput"),  # total throughput in Kbps
	("long", "dot11ax5Received"), 	# cumulative bytes received
	("long", "dot11ax5Sent"), 		# cumulative bytes sent
	("long", "dot11ax5Throughput"),  # total throughput in Kbps
	("long", "dot11bReceived"), 	# cumulative bytes received
	("long", "dot11bSent"), 		# cumulative bytes sent
	("long", "dot11bThroughput"), 	# cumulative throughput in Kbps
	("long", "dot11gReceived"), 	# cumulative bytes received
	("long", "dot11gSent"), 		# cumulative bytes sent
	("long", "dot11gThroughput"),  	# total throughput in Kbps
	("long", "dot11n2_4Received"),  # cumulative bytes received
	("long", "dot11n2_4Sent"), 		# cumulative bytes sent
	("long", "dot11n2_4Throughput"),  # total throughput in Kbps
	("long", "dot11n5Received"), 	# cumulative bytes received
	("long", "dot11n5Sent"), 		# cumulative bytes sent
	("long", "dot11n5Throughput"),  # cumulative throughput in Kbps
	# ("String", "instanceUuid"),	# originally doc. removed in v1.x
	("String", "key"),  # byType {MAC, IP address, "All Guest", text, SSID, text}
	("long", "received"),  # total bytes received
	("long", "sent"),  # total bytes sent
	("String", "subkey"),  # depend on type:
	# for type=ACCESSPOINT; subkey is {"All", enum(SSIDs)}; key is an apMac
	# for type=DEVICE; subkey is {"All", enum(SSIDs)}; key is controller Ip
	# for type=MAPLOCATION; subkey is {"All", enum(SSIDs)}; key is a GroupSpecification.groupName
	# data is useless because e.g. "Floor 1" is repeated w/o qualification
	# for type=SSID; subkey is {virtual domain, "ROOT-DOMAIN"}; key is {"All SSIDs", enum(SSIDs)}
	# subkeys repeat multiple times. all data=0 except for ROOT-DOMAIN
	# for type=VIRTUALDOMAIN; subkey is All; key is virtualDomain - [All Autonomous APs|All SSIDs|All wired|All Wireless]
	# similarly, the keys repeat multiple times, and all data=0 except for ROOT-DOMAIN - [|All Wireless|All SSIDs]
	("long", "throughput"),  # total throughput in Kbps
	("ClientCountTypeEnum", "type"),  # filter
	("long", "wired100MReceived"), 	# 0
	("long", "wired100MSent"), 		# 0
	("long", "wired100MThroughput"),  # 0
	("long", "wired10GReceived"), 	# appeared in 3.6
	("long", "wired10GSent"), 		# appeared in 3.6
	("long", "wired10GThroughput"),  # appeared in 3.6
	("long", "wired10MReceived"), 	# 0
	("long", "wired10MSent"), 		# 0
	("long", "wired10MThroughput"),  # 0
	("long", "wired1GReceived"), 	# 0
	("long", "wired1GSent"), 		# 0
	("long", "wired1GThroughput") 	# 0
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Posted every 20 minutes. Data deleted after 24 hours
# each count value is cumulative total for all time.
add_table(production, Table("v4", "data", "HistoricalRFCounters", False, 5*HOUR, 4*2*NUMAP*3,
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),  # copy of @id uncommented 2018-07-01
	("long", "ackFailureCount"), 	# cumulative count of ACK failures
	("DateBad", "collectionTime"), 	# time that this collection was finished
	# doc changed from string-->Date in v4, but data is not a date
	("long", "failedCount"), 		# cumulative count of Failures
	("long", "fcsErrorCount"), 		# cumulative count of Errors
	("long", "frameDuplicateCount"),
	# ("String", "instanceUuid"),	# originally present, but removed in v1x
	("String", "macAddress_octets"),  # Base radio MAC
	("long", "multipleRetryCount"),  # cumulative count of Multiple Retries
	("long", "retryCount"), 		# cumulative count of Retries
	("long", "rtsFailureCount"), 	# cumulative count of RTS Failures
	("long", "rtsSuccessCount"), 	# cumulative count of RTS Successes
	("long", "rxFragmentCount"), 	# cumulative count of rx fragments
	("long", "rxMulticastFrameCount"),  # cumulative count of rx Multicast frames
	("int", "slotId"), 				# [0:1] changed from string to int in v4
	("long", "txFragmentCount"), 	# cumulative count of tx Fragments
	("long", "txFrameCount"), 		# cumulative count of tx Frames
	("long", "txMulticastFrameCount"),  # cumulative count of tx Multicast frames
	("long", "wepUndecryptableCount")  # cumulative count of non-decryptable WEP
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# introduced in v3 w/changes in v4
# Posted every 20 minutes. Data is deleted after 24 hours.
add_table(production, Table("v4", "data", "HistoricalRFLoadStats", False, 5*HOUR, 4*2*NUMAP*3,
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),
	("int", "channelUtilization"), 	# percent [0:100]
	("int", "clientCount"), 		# number of associated clients
	("DateBad", "collectionTime"), 	# Unix epoch millis with incorrect UTC
	# doc string but epochMillis. String-->Date in v4
	("String", "ethernetMac_octets"),  # AP's ethernet MAC
	("String", "macAddress_octets"),  # base radio MAC
	("int", "poorCoverageClients"),  # count?
	("int", "rxUtilization"), 		# percent [0:100]
	("int", "slotId"), 				# [0|1]
	("int", "txUtilization") 		# percent [0:100]
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Apparently sampled every 20 minutes. However not every sample is present.
# Maybe a sample is not actually posted if it is the same as the previous?
# At 30 days is twice/day; in last day as often as at every 20 minutes.
# On further investigation, samples start disappearing after 20 minutes
add_table(production, Table("v4", "data", "HistoricalRFStats", False, 60*MINUTE, 4*2*NUMAP*3,
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),  # copy of @id
	("ChannelNumberEnum", "channelNumber"),
	# ("int", "channelUtilization"),  # moved to HistoricalRFLoadStats in v3
	("int", "clientCount"),
	("DateBad", "collectionTime"),  # time with incorrect UTC offset
	# doc changed string->Date in v4, but is not date text
	("RFProfileEnum", "coverageProfile"),
	("String", "ethernetMac_octets"),  # AP MAC
	# ("String", "instanceUuid"),	# originally doc. removed in v1
	("RFProfileEnum", "interferenceProfile"),
	("RFProfileEnum", "loadProfile"),
	("String", "macAddress_octets"),  # base radio MAC
	("RFProfileEnum", "noiseProfile"),
	("RadioOperStatusEnum", "operStatus"),
	# ("int", "poorCoverageClients"), # moved to new HistoricalRFLoadStats in v3
	("int", "powerLevel"), 			# [1:8]
	# ("int", "rxUtilization"),		# moved to the HistoricalRFLoadStats in v3
	("int", "slotId"),  # Changed string-->int in v4
	# ("int", "txUtilization")		# moved to the HistoricalRFLoadStats in v3
	).set_id_field("@id").set_time_field("collectionTime")
	.set_rollup(2*HOUR)
	.set_query_options({".full": "true", ".nocount": "true"})
)

# this table will hopefully be read by the serviceDomain generator
add_table(archive, Table('v4', 'op/maps', 'image', True, DAY+offset, 200,
	('long', 'mapId'),
	('String', 'file_name')
	).set_id_field('mapId')
	)

offset += 5*60.0
# Radio details that are not in "Historical" data
# one record per radio
add_table(production, Table("v4", "data", "RadioDetails", True, DAY+offset, 2*NUMAP,
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),  # copy of @id uncommented 2018-07-01
	("RadioAdminStatusEnum", "adminStatus"),
	("AlarmSeverityEnum", "alarmStatus"),
	("float", "antennaAzimAngle"), 	# horizontal angle in degrees
	("AntennaDiversityEnum", "antennaDiversity"),  # antenna diversity?
	("float", "antennaElevAngle"), 	# elevation angle in degrees
	("int", "antennaGain"), 		# external in 2*dBm. e.g. 7 --> 3.5dBm
	("AntennaModeEnum", "antennaMode"),
	("String", "antennaName"), 		# antenna part-no
	("AntennaTypeEnum", "antennaType"),
	("String", "apIpAddress_address"),  # of the access point; blank if {DOWN}
	("String", "apName"), 			# name of the AP
	("String", "baseRadioMac_octets"),  # MAC of the base radio
	("ChannelAssignmentEnum", "channelControl"),
	("ChannelNumberEnum", "channelNumber"),
	("ChannelBandwidthEnum", "channelWidth"),
	("boolean", "cleanAirCapable"),
	("CleanAirSensorStatus", "cleanAirSensorStatus"),
	("boolean", "cleanAirStatus"),
	("int", "clientCount"), 		# clients connected to the radio interface
	("String", "controllerIpAddress_address"),  # for CAPWAP AP only
	("boolean", "dot11nCapable"), 	# true/false
	("String", "ethernetMac_octets"),  # MAC of the ethernet address on the AP
	# ("String", "instanceUuid"),	# originally doc, but removed in v1
	("RadioOperStatusEnum", "operStatus"),
	("int", "port"), 				# controller port number
	("int", "powerLevel"), 			# power level of the radio [0:8]
	("RadioBandEnum", "radioBand"),  # appeared in 3.6
	("RadioRoleEnum", "radioRole"),
	("UnifiedRadioTypeEnum", "radioType"),
	("int", "slotId"), 				# [0:1]
	("TxPowerControlEnum", "txPowerControl"),
	("int", "txPowerOutput") 		# dBm. appeared in 2017-02-16 upgrade
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

offset += 5*60.0
# The neighborGenerator reads AccessPointDetails into workQ for
# cpi.maxConcurrent worker threads. Worker polls one AP at a time,
# which may take up to 30 seconds. Average is about 1 AP/second per worker.
add_table(archive, Table("v4", "op/apService", "rxNeighbors", True, 7*DAY+offset, 10,
	("long", "apId"), 				# a request attribute. Not in the response
	("String", "macAddress_octets"),  # MAC of the AP's radio
	("long", "neighborApId"), 		# Id of the neighbor's parent AP
	("String", "neighborApName"), 	# Name of the neighbor' parent AP
	("int", "neighborChannel"), 	# Channel info which neighbor AP is using
	("RxNeighborChannelWidthEnum", "neighborChannelBandwidth"),
	("String", "neighborIpAddress_address"),
	("String", "neighborMapLocation"),  # name of the service domain location
	("int", "neighborRSSI"), 		# RSSI value of the neighbor
	("int", "neighborSlotId"),
	("RadioBandEnum", "radioBand"),
	("int", "slotId") 				# slotId of AP's radio interface
	).set_paged(False).set_generator(neighborGenerator)
	.set_index_table_path('v4/data/AccessPointDetails')
)

offset += 5*60.0
# For navigating locations.
# One record for each Campus, Outdoor Area, Building, Floor, Default
# A few floors have longitude, latitude, LocationAddress values
# Although "groupId" is a primary key, retrieved data is ordered by group hierarchy, then groupId
add_table(production, Table("v4", "op/groups", "sites", True, DAY+offset, 10000,
	("long", "@id", None), 			# release 3.x changed string-->long
	# ("int", "apCount"),			# not present because noMembersCount=true
	# ("int", "clearedAlarms"),		# not present because noAlarms=true
	# ("int", "clientCount"),		# not present because noMembersCount=true
	# ("int", "criticalAlarms"),	# not present because noAlarms=true
	("String", "description"), 		# value with new site maps
	# ("int", "deviceCount"),		# not present because noMembersCount=true
	("long", "groupId"), 			# release 3.x changed string-->long
	("String", "groupName"),
	# ("int", "informationAlarms"),	# not present because noAlarms=true
	("boolean", "isExplicit"), 		# CPI never returns a value
	("float", "latitude"),  # value with new site maps, when building,outdoor area, campus
	("String", "locationAddress"),  # value with new site maps, when building,outdoor area, campus
	("LocationGroupTypeEnum", "locationGroupType"),  # value with new site maps
	("float", "longitude"),  # value with new site maps, when building,outdoor area, campus
	# ("int", "majorAlarms"),		# not present because noAlarms=true
	# ("int", "membersCount"),		# not present because noMembersCount=true
	# ("int", "minorAlarms"),		# not present because noAlarms=true
	("String", "name"), 			# full hierarchy
	("String", "siteType"), 		# {Campus, Outdoor Area, Building, Floor Area
	# ("int", "unacknowledgedClearedAlarms"),# not present because noAlarms=true
	# ("int", "unacknowledgedCriticalAlarms"),# not present because noAlarms=true
	# ("int", "unacknowledgedInformationAlarms"),# not present because noAlarms=true
	# ("int", "unacknowledgedMajorAlarms"),# not present because noAlarms=true
	# ("int", "unacknowledgedMinorAlarms"),# not present because noAlarms=true
	# ("int", "unacknowledgedWarningAlarms"),# not present because noAlarms=true
	# ("int", "warningAlarms")		# not present because noAlarms=true
	).set_id_field("groupId").set_paged(False)
	.set_query_options({"noAlarms": "true", "noMembersCount": "true"})
)

offset += 5*60.0
add_table(production, Table('v4', 'data', 'ServiceDomains', True, DAY+offset, 200,
	('long', '@id'),
	('String', '@displayName'),
	('int', 'apCount'),					# Count of access points
	('String', 'civicLocation'),		# Location Address
	('String', 'contact'),				# email address
	('int', 'criticalRadioCount'),		# Count of critical radio interfaces
	('ServiceDomainTypeEnum', 'domainType'),  # Type of service domain. Here MULTI_FLOOR is Building
	('int', 'dot11aRadioCount'),		# Count of 802.11a radio interfaces
	('int', 'dot11bRadioCount'),		# Count of 802.11b radio interfaces
	('int', 'dot11gRadioCount'),		# Count of 802.11g radio interfaces
	# ('String', 'file_name'),			# name of jpeg image file. Added by generator
	('int', 'floorIndex'),				# only for floor
	('long', 'groupId'),				# ID of the location group
	('float', 'height'),				# Height of the floor in feet
	('float', 'horizontalPosition'),  # feet from top left corner of the floor to the left edge of the building map
	('double', 'latitude'),				# Longitude of service domain
	('float', 'length'),				# length of service domain in feet
	('double', 'longitude'),			# Longitude of service domain
	('String', 'name'),					# Name of service domain
	('int', 'numOfBasements'),			# number of basements
	('int', 'numOfFloors'),				# number of floors (for building)
	('long', 'parentId'),				# groupId of parent Service Domain
	('String', 'rfModel_name'),			# Calibration model name
	('AlarmSeverityEnum', 'status'), 	# Status of Domain as max severity of all alarms
	('float', 'verticalPosition'),		# distance in feet from top left corner to top edge of the building
	('float', 'width'),					# width of the service domain in feet
	('int', 'wirelessClientsCount') 	# Count of wireless clients
	).set_id_field('@id')
	.set_query_options({".full": "true", ".nocount": "true"})
	)

offset += 5*60.0
# One record for each ProfileName x InterfaceName using the profile
add_table(production, Table("v4", "data", "WlanProfiles", True, DAY+offset, 200,
	("long", "@id"), 				# release 3.x changed string-->long
	("String", "@displayName", None),  # dupl @id uncommented 2018-07-01
	("boolean", "aaaAllowOverride"),  # is allow AAA override?
	("String", "aaaLdapPrimaryServer"),  # 1st LDAP server
	("String", "aaaLdapSecondaryServer"),  # 2nd LDAP server
	("String", "aaaLdapTertiaryServer"),  # 3rd LDAP server
	("boolean", "aaaLocalEapAuthenticationEnabled"),  # local EAP authentication?
	("String", "aaaLocalEapAuthenticationProfileName", False),  # if so, the profile
	("String", "aaaRadiusAccountingPrimaryServer"),  # The 1st, when aaaRadiusAccountingServersEnabled
	("String", "aaaRadiusAccountingSecondaryServer"),  # The 2nd, when aaaRadiusAccountingServersEnabled
	("boolean", "aaaRadiusAccountingServersEnabled"),  # RADIUS accounting?
	("String", "aaaRadiusAccountingTertiaryServer"),  # The 3rd, when aaaRadiusAccountingServersEnabled
	("String", "aaaRadiusAuthenticationPrimaryServer"),  # The 1st, when aaaRadiusAuthorizationServersEnabled
	("String", "aaaRadiusAuthenticationSecondaryServer"),  # The 2nd, when aaaRadiusAuthorizationServersEnabled
	("boolean", "aaaRadiusAuthenticationServersEnabled"),  # is RADIUS authorization?
	("String", "aaaRadiusAuthenticationTertiaryServer"),  # The 3rd, when aaaRadiusAuthorizationServersEnabled
	("boolean", "aaaRadiusInterimUpdateEnabled"),  # RADIUS server accounting interim update?
	("int", "aaaRadiusInterimUpdateInterval"),  # ... if so, the update interval in seconds
	("boolean", "adminStatus"), 	# WLAN administratively enabled?
	("boolean", "advancedAironetIeEnabled"),  # Aironet Info Elements enabled for this WLAN?
	("boolean", "advancedClientExclusionEnabled"),  # auto client exclusion?
	("int", "advancedClientExclusionTimeout"),  # ... if so, timeout in seconds or 0 for infinite
	("boolean", "advancedCoverageHoleDetectionEnabled"),  # coverage hole detection?
	("boolean", "advancedDhcpAddressAssignmentRequired"),  # each client required to obtain IP address via DHCP?
	("boolean", "advancedDhcpProfilingEnabled"),  # should the controller collect DHCP attribtes of clients on this WLAN?
	("String", "advancedDhcpServerIpAddress_address"),  # if valid, an IPv4 DHCP server specified for this WLAN
	("boolean", "advancedDiagnosticChannelEnabled"),  # diagnostic channel available for this WLAN?
	("int", "advancedDot11anDtimPeriod"),  # Delivery Traffic Indication Map (DTIM) for 802.11a/n
	# measured in beacons, during which [broad|multi]cast frames are transmitted
	("long", "advancedDot11bgnDtimPeriod"),  # DTIM interval for 802.11b/g/n
	("boolean", "advancedFlexConnectCentralDhcpProcessingEnabled"),
	("boolean", "advancedFlexConnectLearnClientIpEnabled"),
	("boolean", "advancedFlexConnectLocalAuthEnabled"),
	("boolean", "advancedFlexConnectLocalSwitchingEnabled"),
	("boolean", "advancedFlexConnectNatPatEnabled"),
	("boolean", "advancedFlexConnectOverrideDnsEnabled"),
	("boolean", "advancedFlexConnectReapCentralAssociation"),
	("boolean", "advancedFlexConnectVlanCentralSwitchingEnabled"),
	("boolean", "advancedHttpProfilingEnabled"),
	("boolean", "advancedIpv6Enabled"),
	("boolean", "advancedKtsCacEnabled"),
	("boolean", "advancedLoadBalancingBandSelectEnabled"),
	("boolean", "advancedLoadBalancingEnabled"),
	("int", "advancedMaximumClients"),
	("String", "advancedMdnsProfileName"),
	("boolean", "advancedMdnsSnoopingEnabled"),
	("boolean", "advancedMediaSessionSnoopingEnabled"),
	("DisabledEnabledRequiredEnum", "advancedMfpClientProtection"),
	("boolean", "advancedMfpSignatureGenerationEnabled"),
	("int", "advancedMfpVersion"),
	("String", "advancedOverrideInterfaceAclName", False),
	("String", "advancedOverrideInterfaceIpv6AclName", False),
	("boolean", "advancedPassiveClientEnabled"),
	("Peer2PeerBlockingEnum", "advancedPeerToPeerBlocking"),
	("PmipMobilityTypeEnum", "advancedPmipMobilityType"),
	("String", "advancedPmipProfile", False),
	("String", "advancedPmipRealm", False),
	("boolean", "advancedScanDeferPriority0"),
	("boolean", "advancedScanDeferPriority1"),
	("boolean", "advancedScanDeferPriority2"),
	("boolean", "advancedScanDeferPriority3"),
	("boolean", "advancedScanDeferPriority4"),
	("boolean", "advancedScanDeferPriority5"),
	("boolean", "advancedScanDeferPriority6"),
	("boolean", "advancedScanDeferPriority7"),
	("int", "advancedScanDeferTime"),
	("int", "advancedSessionTimeout"),
	("DisabledAllowedNotAllowedEnum", "advancedWifiDirectClientsPolicy"),
	("boolean", "broadcastSsidEnabled"),
	("int", "ckipKeyIndex"),
	("boolean", "ckipKeyPermutationEnabled"),
	("CkipEncryptionTypeEnum", "ckipKeySize"),
	("boolean", "ckipMmhModeEnabled"),
	("boolean", "ckipSecurityEnabled"),
	("long", "controllerId"),
	("boolean", "hotspot2Enable_hotSpot2Enabled"),
	("int", "hotspot2Wan_downLinkSpeed"),
	("int", "hotspot2Wan_upLinkSpeed"),
	("WanLinkStatusEnum", "hotspot2Wan_wanLinkStatus"),
	("WanSymLinkStatusEnum", "hotspot2Wan_wanSymLinkStatus"),
	("String", "hotspotGeneral_heSsid_octets"),
	("boolean", "hotspotGeneral_internetAccess"),
	("IPv4AddressAvailTypeEnum", "hotspotGeneral_ipv4AddressAvailType"),
	("IPv6AddressAvailTypeEnum", "hotspotGeneral_ipv6AddressAvailType"),
	("NetworkAuthTypeEnum", "hotspotGeneral_networkAuthType"),
	("NetworkTypeEnum", "hotspotGeneral_networkType"),
	("boolean", "hotspotGeneral_status"),  # is 802.11u?
	("boolean", "hotspotServiceAdvertisement_msapEnable", None),
	("long", "hotspotServiceAdvertisement_serverIndex", None),
	("String", "interfaceName"),
	("InterfaceMappingTypeEnum", "interfaceType"),
	("String", "ipAddress"), 		# Mgt addr of WLAN controller. appeared in 3.6
	("boolean", "isWiredLan"),
	("LanTypeEnum", "lanType"),
	("boolean", "layer2FastTransitionEnabled"),
	("boolean", "layer2FastTransitionOverDsEnabled"),
	("int", "layer2FastTransitionReassociationTimeout"),
	("boolean", "layer2MacFilteringEnabled"),
	("boolean", "layer3GlobalWebAuthEnabled"),
	("String", "layer3PreauthenticationAcl", False),
	("String", "layer3PreauthenticationIpv6Acl", False),
	("boolean", "layer3VpnPassthroughEnabled"),
	("String", "layer3WebAuthFlexAcl", False),
	("WlanWebAuthTypeEnum", "layer3WebAuthType"),
	("boolean", "layer3WebPolicyAuthenticationEnabled"),
	("boolean", "layer3WebPolicyConditionalRedirectEnabled"),
	("boolean", "layer3WebPolicyOnMacFailureEnabled"),
	("boolean", "layer3WebPolicyPassthroughEnabled"),
	("boolean", "multicastVlanEnabled"),
	("String", "multicastVlanInterface", False),
	("String", "profileName"),
	("PhoneSupport7920Enum", "qos7920Cac"),
	("String", "qosAvcProfileName"),
	("boolean", "qosNbarVisibilityEnabled"),
	("String", "qosNetflowMonitor"),
	("int", "qosPerSSidBurstRealTimeUpstreamRate"),
	("int", "qosPerSsidAverageDownstreamRate"),
	("int", "qosPerSsidAverageRealTimeDownstreamRate"),
	("int", "qosPerSsidAverageRealTimeUpstreamRate"),
	("int", "qosPerSsidAverageUpstreamRate"),
	("int", "qosPerSsidBurstDownstreamRate"),
	("int", "qosPerSsidBurstRealTimeDownstreamRate"),
	("int", "qosPerSsidBurstUpstreamRate"),
	("int", "qosPerUserAverageDownstreamRate"),
	("int", "qosPerUserAverageRealTimeDownstreamRate"),
	("int", "qosPerUserAverageRealTimeUpstreamRate"),
	("int", "qosPerUserAverageUpstreamRate"),
	("int", "qosPerUserBurstDownstreamRate"),
	("int", "qosPerUserBurstRealTimeDownstreamRate"),
	("int", "qosPerUserBurstRealTimeUpstreamRate"),
	("int", "qosPerUserBurstUpstreamRate"),
	("QosEnum", "qosProfile"),
	("DisabledAllowedRequiredEnum", "qosWmmPolicy"),
	("RadioPolicyEnum", "radioPolicy"),
	("String", "ssid"),
	("String", "vpnPassThroughGatewayAddress_address"),
	("String", "webAuthExternalUrl"),
	("String", "webAuthLoginFailurePage", False),
	("String", "webAuthLoginPage", False),
	("String", "webAuthLogoutPage", False),
	("boolean", "webPassthruEmailInputEnabled"),
	("boolean", "wepAllowSharedKeyAuthentication"),
	("int", "wepKeyIndex"),
	("WepEncryptionTypeEnum", "wepKeySize"),
	("boolean", "wepSecurityEnabled"),
	("long", "wlanId"),
	("boolean", "wpa2Enabled"),
	("boolean", "wpa2EncryptionProtocolAes"),
	("boolean", "wpa2EncryptionProtocolTkip"),
	("boolean", "wpaAuthenticationKeyManagement8021x"),
	("boolean", "wpaAuthenticationKeyManagementCckm"),
	("boolean", "wpaAuthenticationKeyManagementFt8021x"),
	("boolean", "wpaAuthenticationKeyManagementFtPsk"),
	("boolean", "wpaAuthenticationKeyManagementPmf8021x"),
	("boolean", "wpaAuthenticationKeyManagementPmfPsk"),
	("boolean", "wpaAuthenticationKeyManagementPsk"),
	("boolean", "wpaEnabled"),
	("boolean", "wpaEncryptionProtocolAes"),
	("boolean", "wpaEncryptionProtocolTkip"),
	("String", "wpaPresharedKey"), 	# appeared in 3.6
	("PskFormatEnum", "wpaPresharedKeyFormat"),  # appeared in 3.6
	("boolean", "wpaSecurityEnabled"),
	("x8021EncryptionTypeEnum", "x8021KeySize"),
	("boolean", "x8021SecurityEnabled")
	)
	# ignore this subtable, because we don't have hot spots
	.subTable("hotspot2Operators", [("float", "polledTime"), ("long", "@id")],
		("int", "operatorId", False),
		("String", "opeatorLang", False),
		("String", "operatorName", False)
	)
	# ignore this subtable, because we don't have hot spots
	.subTable("hotspot2Ports", [("float", "polledTime"), ("long", "@id")],
		("int", "portConfigId", False),
		("PortNoEnum", "portNo", False),
		("PortStatusEnum", "portStatus", False),
		("ProtocolNameEnum", "protocolName", False)
	)
	# ignore this subtable, because we don't have hot spots
	.subTable("hotspotCellularNetworks", [("float", "polledTime"), ("long", "@id")],
		("String", "countryCode", False),
		("int", "gppIndex", False),
		("String", "networkCode", False)
	)
	# ignore this subtable, because we don't have hotspots
	.subTable("hotspotDomains", [("float", "polledTime"), ("long", "@id")],
		("int", "domainId", False),
		("String", "domainName", False)
	)
	# ignore this subtable, because we don't have hotspots
	.subTable("hotspotOuiConfigs", [("float", "polledTime"), ("long", "@id")],
		("String", "oui", False),
		("String", "ouiId", False),
		("boolean", "ouiInBeacon", False)
	)
	# ignore this subtable, because we don't have hotspots
	.subTable("hotspotRealms", [("float", "polledTime"), ("long", "@id")],
		("int", "realmId", False),
		("String", "realmName", False)
	)
	.subTable("hotspotRealms_realmEapMethods",
		[("float", "polledTime"), ("long", "@id"), ("int", "realmId")],
		("int", "realmEapId", False),
		("RealmEapMethodEnum", "realmEapMethod", False)
	)
	.subTable("hotspotRealms_realmEapMethods_innerAuthMethods",
		[("float", "polledTime"), ("long", "@id"), ("int", "realmId"), ("int", "realmEapId")],
		("int", "realmEapAuthId", False),
		("RealmEapAuthMethodEnum", "realmEapAuthMethod", False),
		("RealmEapAuthParamEnum", "realmEapAuthParam", False)
	)
	.set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# O L D   T A B L E   D E F I N I T I O N S

add_table(archive, Table("v2", "data", "ClientSessions", False, DAY+3*HOUR, 8000,
	("String", "@id"),
	("String", "@displayName"), 	# copy of @id uncommented 2018-07-01
	("String", "adDomainName"), 	# AD domain from ISE; blank in v2
	("String", "anchorIpAddress"),  # of mobility anchor controller, or 0.0.0.0
	("String", "apIpAddress", False),  # doc but not present in v1, undoc in v3; reappeared in v3.4
	("String", "apMacAddress"), 	# Associated AP MAC address
	("String", "apName", False), 	# doc but not present in v1. undoc in v3; reappeared in v3.4
	("AuthenticationAlgorithmEnum", "authenticationAlgorithm"),
	("String", "authorizationPolicy"),  # from ISE; doc but not present in v1
	("long", "bytesReceived"), 		# cumulative bytes received during this session
	("long", "bytesSent"), 			# cumulative bytes sent during this session
	("String", "clientInterface"),  # {case[auth|guest]*, ic-inside, management}
	("ConnectionTypeEnum", "connectionType"),
	("String", "ctsSecurityGroup"),  # from ISE; currently not present
	("String", "deviceIpAddress"), 	# controller IP address
	("String", "deviceName"), 		# controller or switch name
	("EapTypeEnum", "eapType"),
	("EncryptionCypherEnum", "encryptionCypher"),  # Client cypher
	# ("String", "instanceUuid"),	# originally doc, but removed in v1
	("String", "ipAddress"), 		# Client IP address
	("ClientIpTypeEnum", "ipType"),
	("String", "location"), 		# campus > building > floor
	("String", "macAddress"), 		# Client MAC
	("long", "packetsReceived"), 	# cumulative received in this session
	("long", "packetsSent"), 		# cumulative sent in this session
	("PolicyTypeStatusEnum", "policyTypeStatus"),  # Client policy status
	("ClientSpeedEnum", "portSpeed"),
	("PostureStatusEnum", "postureStatus"),
	("String", "profileName"), 		# WLAN Profile Name
	("ClientProtocolEnum", "protocol"),
	("String", "roamReason"), 		# not present in v1
	("int", "rssi"), 				# RSSI (dBm) from last polling
	("SecurityPolicyEnum", "securityPolicy"),  # Client
	("epochMillis", "sessionEndTime"),  # time the session finished, or future
	("epochMillis", "sessionStartTime"),  # time the session started
	("int", "snr"), 				# from last polling during the session
	("String", "ssid"), 			# SSID
	("double", "throughput"), 		# session Avg. Blank while session open
	("String", "userName"), 		# Client username
	("String", "vlan"), 			# vlan name
	("WebSecurityEnum", "webSecurity"),  # is client auth via WebAuth?
	("String", "wgbMacAddress"), 	# WorkGroup Bridge MAC, or 00:00:00:00:00:00:00
	("WGBStatusEnum", "wgbStatus") 	# Client type
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
	.set_pager('cs_pager')
)

add_table(archive, Table("v2", "data", "HistoricalClientCounts", False, 1, 120000,
	("String", "@id"),
	("String", "@displayName"), 	# copy of @id uncommented 2018-07-01
	("int", "authCount"), 			# as of last collection time
	("epochMillis", "collectionTime"),  # Unix epoch millis when record was collected
	("int", "count"), 				# total client count
	("int", "dot11aAuthCount"),
	("int", "dot11aCount"),
	("int", "dot11acAuthCount"),
	("int", "dot11acCount"),
	("int", "dot11bAuthCount"),
	("int", "dot11bCount"),
	("int", "dot11gAuthCount"),
	("int", "dot11gCount"),
	("int", "dot11n2_4AuthCount"),
	("int", "dot11n2_4Count"),
	("int", "dot11n5AuthCount"),
	("int", "dot11n5Count"),
	# ("String", "instanceUuid"),	# originally doc, but undoc from v1
	("String", "key"),
	("String", "subkey"),
	# for type=ACCESSPOINT; subkey is {"All", enum(SSIDs)}; key is an apMac
	# for type=DEVICE; subkey is {"All", enum(SSIDs)}; key is controller Ip
	# for type=MAPLOCATION; subkey is {"All", enum(SSIDs)}; key is a GroupSpecification.groupName
	# data is useless because e.g. "Floor 1" is repeated w/o qualification
	# for type=SSID; subkey is {virtual domain, "ROOT-DOMAIN"}; key is {"All SSIDs", enum(SSIDs)}
	# subkeys repeat multiple times. all data=0 except for ROOT-DOMAIN
	# for type=VIRTUALDOMAIN; subkey is All; key is virtualDomain - [All Autonomous APs|All SSIDs|All wired|All Wireless]
	# similarly, the keys repeat multiple times, and all data=0 except for ROOT-DOMAIN - [|All Wireless|All SSIDs]
	("ClientCountTypeEnum", "type"),  #
	("int", "wgbAuthCount"), 		# clients auth as WGB or wired guest
	("int", "wgbCount"), 			# clients connected as WorkGroup Bridge or wired guest
	("int", "wired100MAuthCount"),
	("int", "wired100MCount"),
	("int", "wired10GAuthCount", False),  # appeared in 3.6
	("int", "wired10GCount", False),  # appeared in 3.6
	("int", "wired10MAuthCount"),
	("int", "wired10MCount"),
	("int", "wired1GAuthCount"),
	("int", "wired1GCount")
	# ("String", "adminStatus")		# undoc field appeared in 2017-02-16 upgrade, then undoc
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(archive, Table("v1", "data", "HistoricalClientCountsV0", False, 1, 120000,
	("String", "@id"),
	("String", "@displayName"), 	# copy of @id
	("int", "authCount"),
	("epochMillis", "collectionTime"),  # millis
	("int", "count"),
	("int", "dot11aAuthCount"),
	("int", "dot11aCount"),
	("int", "dot11acAuthCount"),
	("int", "dot11acCount"),
	("int", "dot11bAuthCount"),
	("int", "dot11bCount"),
	("int", "dot11gAuthCount"),
	("int", "dot11gCount"),
	("int", "dot11n2_4AuthCount"),
	("int", "dot11n2_4Count"),
	("int", "dot11n5AuthCount"),
	("int", "dot11n5Count"),
	("String", "instanceUuid"),
	("String", "key"), 		# byType {MAC, IP address, "All Guest", text, SSID, text}
	("String", "subkey"), 	# byType{SSID, "All"||SSID, "GUEST", SSID, map text, "All"}
	("ClientCountTypeEnum", "type"),
	("int", "wgbAuthCount"),
	("int", "wgbCount"),
	("int", "wired100MAuthCount"),
	("int", "wired100MCount"),
	("int", "wired10MAuthCount"),
	("int", "wired10MCount"),
	("int", "wired1GAuthCount"),
	("int", "wired1GCount")
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(archive, Table("v2", "data", "HistoricalClientTraffics", False, 1, 40000,
	("String", "@id"),
	("String", "@displayName", False),  # copy of @id uncommented 2018-07-01
	# ("String", "@uuid"),			# blank
	("epochMillis", "collectionTime"),  # millis
	("String", "dot11aReceived"), 	# cumulative bytes received
	("long", "dot11aSent"), 		# cumulative bytes sent
	("long", "dot11aThroughput"), 	# cumulative throughput in Kbps
	("long", "dot11acReceived"), 	# cumulative bytes received
	("long", "dot11acSent"), 		# cumulative bytes sent
	("long", "dot11acThroughput"), 	# total throughput in Kbps
	("String", "dot11bReceived"), 	# cumulative bytes received
	("long", "dot11bSent"), 		# cumulative bytes sent
	("long", "dot11bThroughput"), 	# cumulative throughput in Kbps
	("String", "dot11gReceived"), 	# cumulative bytes received
	("long", "dot11gSent"), 		# cumulative bytes sent
	("long", "dot11gThroughput"), 	# total throughput in Kbps
	("String", "dot11n2_4Received"),  # cumulative bytes received
	("long", "dot11n2_4Sent"), 		# cumulative bytes sent
	("long", "dot11n2_4Throughput"),  # total throughput in Kbps
	("String", "dot11n5Received"), 	# cumulative bytes received
	("long", "dot11n5Sent"), 		# cumulative bytes sent
	("long", "dot11n5Throughput"), 	# cumulative throughput in Kbps
	# ("String", "instanceUuid"),	# originally doc. undoc in v1.x
	("String", "key"), 			# byType {MAC, IP address, "All Guest", text, SSID, text}
	("String", "received"), 		# total bytes received
	("long", "sent"), 				# total bytes sent
	("String", "subkey"), 			# depends on type:
	# for type=ACCESSPOINT; subkey is {"All", enum(SSIDs)}; key is an apMac
	# for type=DEVICE; subkey is {"All", enum(SSIDs)}; key is controller Ip
	# for type=MAPLOCATION; subkey is {"All", enum(SSIDs)}; key is a GroupSpecification.groupName
	# data is useless because e.g. "Floor 1" is repeated w/o qualification
	# for type=SSID; subkey is {virtual domain, "ROOT-DOMAIN"}; key is {"All SSIDs", enum(SSIDs)}
	# subkeys repeat multiple times. all data=0 except for ROOT-DOMAIN
	# for type=VIRTUALDOMAIN; subkey is All; key is virtualDomain - [All Autonomous APs|All SSIDs|All wired|All Wireless]
	# similarly, the keys repeat multiple times, and all data=0 except for ROOT-DOMAIN - [|All Wireless|All SSIDs]
	("long", "throughput"),  # total throughput in Kbps
	("ClientCountTypeEnum", "type"),
	("String", "wired100MReceived"),  # 0
	("long", "wired100MSent"), 		# 0
	("long", "wired100MThroughput"),  # 0
	("String", "wired10GReceived", False),  # appeared in 3.6
	("long", "wired10GSent", False),  # appeared in 3.6
	("long", "wired10GThroughput"),  # appeared in 3.6
	("String", "wired10MReceived"),  # 0
	("long", "wired10MSent"), 		# 0
	("long", "wired10MThroughput"),  # 0
	("String", "wired1GReceived"),  # 0
	("long", "wired1GSent"), 		# 0
	("long", "wired1GThroughput") 	# 0
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# statistics are during this session
add_table(archive, Table("v2", "data", "HistoricalClientStats", False, 1, 16000,
	("String", "@id"), 				# Session id
	("String", "@displayName", False),  # copy of @id uncommented 2018-07-01
	("long", "bytesReceived"), 		# cumulative bytes received
	("long", "bytesSent"), 			# cumulative bytes sent
	("epochMillis", "collectionTime"),  # Unix epoch millis
	("float", "dataRate"), 			# reading data rate Mbps
	("long", "dataRetries"), 		# cumulative data Retries
	# ("String", "instanceUuid"),	# originally doc. removed in v1
	("String", "macAddress"), 		# client MAC
	("long", "packetsReceived"), 	# cumulative packets received
	("long", "packetsSent"), 		# cumulative packets Sent
	("long", "raPacketsDropped"), 	# cumulative IPv6 RA packets dropped
	("int", "rssi"),  				# RSSI (dBm) as measured by AP
	("long", "rtsRetries"), 		# cumulative RTS Retries
	("long", "rxBytesDropped"), 	# cumulative rx Bytes dropped
	("long", "rxPacketsDropped"), 	# cumulative rx Packets dropped
	("int", "snr"), 				# SNR as measured by the AP
	("long", "txBytesDropped"), 	# cumulative tx Bytes dropped
	("long", "txPacketsDropped") 	# cumulative tx Packets dropped
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# each count is total for all time.
add_table(archive, Table("v2", "data", "HistoricalRFCounters", False, 1, 4*2*NUMAP,
	("String", "@id"),
	("String", "@displayName", False),  # copy of @id uncommented 2018-07-01
	("long", "ackFailureCount"), 	# cumulative count of ACK failures
	("DateBad", "collectionTime"), 	# epoch millis that collection finished
	("long", "failedCount"), 		# cumulative count of Failures
	("long", "fcsErrorCount"), 		# cumulative count of Errors
	("long", "frameDuplicateCount"),
	# ("String", "instanceUuid"),	# originally present, but removed in v1x
	("String", "macAddress"), 		# Base radio MAC
	("long", "multipleRetryCount"),  # cumulative count of Multiple Retries
	("long", "retryCount"), 		# cumulative count of Retries
	("long", "rtsFailureCount"), 	# cumulative count of RTS Railures
	("long", "rtsSuccessCount"), 	# cumulative count of RTS Successes
	("long", "rxFragmentCount"), 	# cumulative count of rx fragments
	("long", "rxMulticastFrameCount"),  # cumulative of rx Multicast frames
	("String", "slotId"), 			# [0:1]
	("long", "txFragmentCount"), 	# cumulative count of tx Fragments
	("long", "txFrameCount"),		# cumulative count of tx Frames
	("long", "txMulticastFrameCount"),  # cumulative of tx Multicast frames
	("long", "wepUndecryptableCount")  # cumulative of undecryptable WEP
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(archive, Table("v2", "data", "HistoricalRFStats", False, 1, 4*2*NUMAP,
	("String", "@id"),
	("String", "@displayName", False),  # copy of @id uncommented 2018-07-01
	("ChannelNumberEnum", "channelNumber"),
	("int", "channelUtilization"), 	# percent [0:100]
	("int", "clientCount"), 		# number of associated clients
	("String", "collectionTime"), 	# Unix epoch millis
	("RFProfileEnum", "coverageProfile"),
	("String", "ethernetMac"), 		# AP MAC address
	# ("String", "instanceUuid"),	# originally doc. but dropped in v1.
	("RFProfileEnum", "interferenceProfile"),
	("RFProfileEnum", "loadProfile"),
	("String", "macAddress"), 		# base radio MAC
	("RFProfileEnum", "noiseProfile"),
	("RadioOperStatusEnum", "operStatus"),
	("int", "poorCoverageClients"),  # Count?
	("int", "powerLevel"), 			# [1:8]
	("int", "rxUtilization"), 		# percent [0:100]
	("String", "slotId"), 			# [0|1]
	("int", "txUtilization"), 		# percent [0:100]
	).set_id_field("@id").set_time_field("collectionTime")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(archive, Table("v2", "data", "AccessPointDetails", True, HOUR*8, 10000,
	("String", "@id"), 				# Access Point id
	("String", "@displayName", False),  # duplicates @id uncommented 2018-07-01
	("ApAdminStatusEnum", "adminStatus"),
	("String", "apType"), 			# AP type
	# autonomousAP and cdpNeighbors are defined as array of objects. may be:
	# 	totally absent
	# 	present as a single object with individual components
	# 	present as array of objects with individual components
	# Ignore such embedded arrays in this pure relational model
	("String", "cdpNeighbors_cdpNeighbor_capabilities", False),
	("String", "cdpNeighbors_cdpNeighbor_duplex", False),
	("String", "cdpNeighbors_cdpNeighbor_interfaceSpeed", False),
	("String", "cdpNeighbors_cdpNeighbor_localPort", False),
	("String", "cdpNeighbors_cdpNeighbor_neighborIpAddress", False),
	("String", "cdpNeighbors_cdpNeighbor_neighborName", False),
	("String", "cdpNeighbors_cdpNeighbor_neighborPort", False),
	("String", "cdpNeighbors_cdpNeighbor_platform", False),
	("String", "clientCount"), 		# doc as String, but delivered as NUMBER
	("String", "clientCount_2_4GHz"),  # doc as String, but delivered as NUMBER
	("int", "clientCount_5GHz"),
	("String", "ethernetMac"), 		# AP MAC
	# ("String", "instanceUuid"), 	# originally doc but not present in v1
	("String", "ipAddress"), 		# AP IP address
	("String", "locationHeirarchy"),  # map location entire hierarchy
	("String", "macAddress"), 		# base radio MAC
	("String", "mapLocation"), 		# SNMP location?
	("String", "model"), 			# AP model
	("String", "name"), 			# AP name
	("ReachabilityStateEnum", "reachabilityStatus"),  # [not present]
	("String", "serialNumber"),
	("String", "softwareVersion"),
	("AlarmSeverityEnum", "status"),
	("String", "type"), 			# {CAPWAP, Autonomous, UnifiedAp}
	("int", "unifiedApInfo_instanceId"),  # not present
	("long", "unifiedApInfo_instanceVersion"),  # not present
	("int", "unifiedApInfo_apCertType"),
	("String", "unifiedApInfo_apGroupName"),
	("String", "unifiedApInfo_apMode"),  # doc as String but delivered as NUMBER
	("int", "unifiedApInfo_apStaticEnabled"),
	("String", "unifiedApInfo_bootVersion"),
	("long", "unifiedApInfo_capwapJoinTakenTime"),
	("long", "unifiedApInfo_capwapUpTime"),
	("String", "unifiedApInfo_controllerIpAddress"),
	("String", "unifiedApInfo_controllerName"),
	("String", "unifiedApInfo_contryCode"),  # misspelled ...contry...
	("boolean", "unifiedApInfo_encryptionEnabled"),
	("String", "unifiedApInfo_flexConnectGroupName"),  # not present
	("boolean", "unifiedApInfo_flexConnectMode"),
	("String", "unifiedApInfo_iosVersion"),
	("boolean", "unifiedApInfo_linkLatencyEnabled"),
	("MeshRoleEnum", "unifiedApInfo_lradMeshNode_meshRole", False),  # appeared in 2018-06-24 upgrade
	("String", "unifiedApInfo_maintenanceMode", False),  # appeared in 2018-06-24 upgrade
	("PoeStatusEnumInt", "unifiedApInfo_poeStatus"),  # doc as String, but NUMBER
	("String", "unifiedApInfo_poeStatusEnum"),  # {LOW, FIFTEENDOTFOUR, SIXTEENDOTEIGHT, NORMAL, EXTERNAL, MIXEDMODE}
	("int", "unifiedApInfo_portNumber"),
	("int", "unifiedApInfo_powerInjectorState"),
	("int", "unifiedApInfo_preStandardState"),
	("String", "unifiedApInfo_primaryMwar"),
	("boolean", "unifiedApInfo_rogueDetectionEnabled"),
	("String", "unifiedApInfo_secondaryMwar"),  # not present
	("boolean", "unifiedApInfo_sshEnabled"),
	("int", "unifiedApInfo_statisticsTimer"),
	("boolean", "unifiedApInfo_telnetEnabled"),
	("String", "unifiedApInfo_tertiaryMwar"),  # not present
	("boolean", "unifiedApInfo_vlanEnabled"),  # not present -- no FlexConnect
	("long", "unifiedApInfo_vlanNativeId"),
	("long", "unifiedApInfo_WIPSEnabled"),
	# array
	("ignore", "unifiedApInfo_wlanProfiles", False),  # appeared after 2017-02-16 software upgrade
	("ignore", "unifiedApInfo_wlanProfiles_wlanProfile", False),  # new Array object in 2017-02-16 upgrade
	("ignore", "unifiedApInfo_wlanProfiles_wlanProfile_broadcastSsidEnabled", False),  # new Array after 2017-02-16 upgrade
	("ignore", "unifiedApInfo_wlanProfiles_wlanProfile_profileName", False),  # new Array after 2017-02-16 upgrade
	("ignore", "unifiedApInfo_wlanProfiles_wlanProfile_ssid", False),  # new Array after 2017-02-16 upgrade
	# ("ignore", "unifiedApInfo_wlanProfiles_broadcastSsidEnabled", False),
	# ("ignore", "unifiedApInfo_wlanProfiles_profileName", False),
	# ("ignore", "unifiedApInfo_wlanProfiles_ssid", False),
	# *** doc as compound structure(String ssid, long vlanId, long wlanId) but delivered as None string
	("ignore", "unifiedApInfo_wlanVlanMappings", False),
	("long", "upTime") 				# millis
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(archive, Table("v2", "data", "ClientDetails", True, 8*HOUR, 70000,
	("String", "@id"),
	("String", "@displayName", False),  # dupl @id. uncommented 2018-07-01
	("String", "adDomainName"), 	# AD domain acquired from ISE
	("String", "apIpAddress_address"),  # associated AP IP address
	("String", "apMacAddress"), 	# associated AP MAC address
	("String", "apName"), 			# associated AP name
	("int", "apSlotId"), 			# associated AP slot ID
	("epochMillis", "associationTime"),  # current or last session start time
	("String", "auditSessionId"), 	# Client audit session ID
	("AuthenticationAlgorithmEnum", "authenticationAlgorithm"),  # client's auth. alg
	("String", "authnTimeStamp"), 	# acquired from ISE
	("String", "authorizationPolicy"),  # acquired from ISE
	("String", "authorizedBy"), 	# Authorization provider
	# ("long", "bytesReceived"),	# only present in v1
	# ("long", "bytesSent"),   		# only present in v1
	("CcxFSVersionEnum", "ccxFSVersion"),  # client card version v2
	("CcxFSVersionEnum", "ccxLSVersion"),  # client card version v2
	("CcxFSVersionEnum", "ccxMSVersion"),  # client card version v2
	("CcxFSVersionEnum", "ccxVSVersion"),  # client card version v2
	("CCXVersionEnum", "ccxVersion"),  # client card version
	("ClientAclAppliedEnum", "clientAaaOverrideAclApplied"),  # AA override applied?
	("String", "clientAaaOverrideAclName"),  # ACL name
	("ClientAclAppliedEnum", "clientAclApplied"),  # ACL applied to client v2
	("String", "clientAclName"), 	# ACL name applied to the client
	("ClientApModeEnum", "clientApMode"),  #
	("String", "clientInterface"), 	# interface LAN
	("String", "clientRedirectUrl"),  # Redirect URL applied to the client
	("ConnectionTypeEnum", "connectionType"),  # from ISE
	("String", "ctsSecurityGroup"),
	("String", "deviceIpAddress_address"),  # of assoc controller or switch
	("String", "deviceName"), 		# name of assoc controller or switch
	("String", "deviceType"), 		# Client device type acquired from ISE
	("EapTypeEnum", "eapType"),
	("EncryptionCypherEnum", "encryptionCypher"),  # Client encrpyt. cypher
	("String", "failureCode"), 		# from ISE
	("String", "failureStep"), 		# from ISE
	("epochMillis", "firstSeenTime"),  # time client was first discovered
	("String", "hostname"), 		# reverse DNS from client IP address
	("long", "hreapLocallyAuthenticated"),  # authenticated via HREAP?
	("String", "ifDescr"), 			# SNMP ifDescr of the connected switch
	("int", "ifIndex"), 			# SNMP ifIndex if the connected switch
	# ("String", "instanceUUid"),	# not in the doc, but present in v2.
	("String", "ipAddress_address"),  # Client IP address
	("ClientIpTypeEnum", "ipType"),  # Client IP type
	("String", "iseName"), 			# ISE name which the client is reported
	("String", "location"), 		# Map location hierarchy
	("String", "macAddress"), 		# Client MAC address
	("MobilityStatusEnum", "mobilityStatus"),  # Client mobility status
	("NACStateEnum", "nacState"), 	# Client NAC state
	# ("long", "packetsReceived"),	# only in v1
	# ("long", "packetsSent"),		# only in v1
	("SecurityPolicyEnum", "policyType"),  # v2
	("PolicyTypeStatusEnum", "policyTypeStatus"),  # Client from ISE
	("PostureStatusEnum", "postureStatus"),  # Client from ISE
	("ClientProtocolEnum", "protocol"),  # [last] connection protocol
	# ("int", "rssi"),				# only in v1
	("String", "radiusResponse"), 	# from ISE
	("SecurityPolicyStatusEnum", "securityPolicyStatus"),  # Client on network?
	# ("int", "snr"),				# only in v1
	("ClientSpeedEnum", "speed"), 	# wired port speed or UNKNOWN for wireless
	("String", "ssid"),  # [last] SSID
	("ClientStatusEnum", "status"),  # Client connection
	# ("double", "throughput"),		# only in v1
	# ("long", "traffic"),			# only in v1
	("long", "updateTime"), 		# last epoch millis  record was updated
	("String", "userName"), 		# Client username
	("String", "vendor"), 			# Vendor name of the client NIC from OUI mapping
	("String", "vlan"), 			# VLAN ID doc as String, but JSON is NUMBER
	("String", "vlanName"), 		# [blank] name of the VLAN
	("WebSecurityEnum", "webSecurity"),  # client is authenticated by WebAuth
	("WepStateEnum", "wepState"), 	#
	("String", "wgbMacAddress"), 	# if client s a WorkGroup Bridge
	("WGBStatusEnum", "wgbStatus"),  # Client WorkGroup Bridge status
	("WiredClientTypeEnum", "wiredClientType")  #
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

# Information is not useful, cease polling
# one record for each Controller in the inventory
offset += 5*60.0
add_table(archive, Table("v2", "data", "ConfigArchives", True, DAY+offset, 10000,
	("String", "@id"),
	("String", "@displayName", False),  # duplicate of @id
	("String", "deviceIpAddress"),  # Controller IP
	("String", "deviceName"), 		# Controller host name
	# ("String", "instanceUuid"),	# originally doc, but not present in v1
	("String", "lastMessage"), 		# error message, if last collection failed
	("boolean", "lastSuccessful") 	# result of last collection
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

offset += 5*60.0
add_table(archive, Table("v2", "data", "Devices", True, DAY+offset, 10000,
	("long", "@id", False), 		# uncommented 2018-07-01
	("String", "@displayName", False),  # duplicates @id uncommented 2018-07-01
	("String", "adminStatus"), 		# added by 2017-02-16 software upgrade
	("int", "clearedAlarms"), 		# removed in v3
	("String", "collectionDetail"),  # html string
	# ("String", "collectionStatus")
	# not present in v1 -- {[MAJOR]COMPLETED, [PARTIAL]COLLECTIONFAILURE, SNMPCONNECTIVITYFAILED,
	# WRONG[HTTP]CREDENTIALS, [MAJOR|MINOR|]SYNCHRONIZING, SNMPUSERAUTHENTIFICATIONFAILED, NOLICENSE, ADDINITIATED,
	# DELETEINPROGRESS, PINGUNREACHIBLE, SPT_ONLY, IN_SERVICE[_MAINTENANCE]}
	("String", "collectionTime"), 	# Instant
	("String", "creationTime"), 	# Instant
	("int", "criticalAlarms"),
	("long", "deviceId"), 			# delivered as a number in v1
	("String", "deviceName"),
	("String", "deviceType"),
	("int", "informationAlarms"), 	# removed in v3
	# ("String", "instanceUuid"),	# originally doc, but not present in v1.
	("String", "ipAddress"),
	("String", "location"),
	("int", "majorAlarms"), 		# removed in v3
	("LifecycleStateEnum", "managementStatus"),  #
	("int", "minorAlarms"), 		# removed in v3
	# (StringArray.class, "manufacturerPartNr")# new in v2, but doesn't fit relational model
	("String", "productFamily"),
	("ReachabilityStateEnum", "reachability"),
	("String", "softwareType"),
	("String", "softwareVersion"),
	("int", "warningAlarms") 		# removed in v3
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

offset += 5*60.0
add_table(archive, Table("v1", "data", "Devices", True, DAY+offset, 10000,
	("String", "@id"),
	("String", "@displayName"),
	("int", "clearedAlarms"),
	("String", "collectionDetail"),
	("instant", "collectionTime"),
	("instant", "creationTime"),
	("int", "criticalAlarms"),
	("long", "deviceId"),
	("String", "deviceName"),
	("String", "deviceType"),
	("int", "informationAlarms"),
	("String", "instanceUuid"),
	("String", "ipAddress"),
	("String", "location"),
	("int", "majorAlarms"),
	("LifecycleStateEnum", "managementStatus"),
	("int", "minorAlarms"),
	("String", "productFamily"),
	("ReachabilityStateEnum", "reachability"),
	("String", "softwareType"),
	("String", "softwareVersion"),
	("int", "warningAlarms")
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)


# Radio details that are not in "Historical" data
# one record per radio
offset += 5*60.0
add_table(archive, Table("v2", "data", "RadioDetails", True, DAY+offset, 2*NUMAP,
	("String", "@id"),
	("String", "@displayName", False),  # copy of @id uncommented 2018-07-01
	("RadioAdminStatusEnum", "adminStatus"),
	("AlarmSeverityEnum", "alarmStatus"),
	("float", "antennaAzimAngle"), 	# horizontal antenna angle in degrees
	("String", "antennaDiversity"),  # antenna diversity? enum{Connector A, Enabled}
	("float", "antennaElevAngle"), 	# elevation angle in degrees
	("int", "antennaGain"), 		# external gain in 2*dBm. e.g. 7 --> 3.5dBm
	("String", "antennaMode"), 		# enum {Omni, Directional, NA}
	("String", "antennaName"), 		# antenna part-no
	("String", "antennaType"), 		# Internal or External
	("String", "apIpAddress"), 		# of the access point; blank if {DOWN}
	("String", "apName"), 			# name of the AP
	("String", "baseRadioMac"), 	# MAC of the base radio
	("String", "channelControl"), 	# enum{Automatic, Custom}
	("int", "channelNumber"), 		# int, not enum
	("String", "channelWidth"), 	# enum{"20 MHz", "Above 40MHz", "NA"}
	("String", "cleanAirCapable"),  # enum{No, Yes}
	("String", "cleanAirSensorStatus"),  # enum{Down, NA, Up}
	("String", "cleanAirStatus"), 	# enum{No, Yes}
	("String", "clientCount"), 		# clients connected to the radio interface
	("String", "controllerIpAddress"),  # for CAPWAP AP only
	("boolean", "dot11nCapable"), 	# enum{TRUE, FALSE}
	("String", "ethernetMac"), 		# MAC of the ethernet address on the AP
	# ("String", "instanceUuid"),	# originally doc, but undoc in v1
	("RadioOperStatusEnum", "operStatus"),
	("int", "port"), 				# controller port number
	("int", "powerLevel"), 			# power level of the radio [0:8]
	("RadioBandEnum", "radioBand", False),  # appeared in 3.6
	("RadioRoleEnum", "radioRole"),
	("String", "radioType"), 		# enum{"801.11[a|a/n|a/n/ac|b/g|b/g/n]"}
	("int", "slotId"), 				# [0:1]
	("String", "txPowerControl"), 	# enum{Automatic, Custom}
	("int", "txPowerOutput") 		# in dBm. appeared in 2017-02-16 upgrade
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

offset += 5*60.0
# one record per radio
add_table(archive, Table("v1", "data", "RadioDetailsV0", True, DAY+offset, 2*NUMAP,
	("String", "@id"),
	("String", "@displayName"), 	# copy of @id
	("RadioAdminStatusEnum", "adminStatus"),
	("AlarmSeverityEnum", "alarmStatus"),
	("float", "antennaAzimAngle"),
	("String", "antennaDiversity"),
	("float", "antennaElevAngle"),
	("int", "antennaGain"),
	("String", "antennaMode"),
	("String", "antennaName"),
	("String", "antennaType"),
	("String", "apIpAddress"), 		# AP IP address; blank if {DOWN}
	("String", "apName"),
	("String", "baseRadioMac"), 	# MAC
	("String", "channelControl"), 	# enum{Automatic, Custom}
	("int", "channelNumber"), 		# int, not enum
	("String", "channelWidth"), 	# enum{"20 MHz", "Above 40MHz", "NA"}
	("String", "cleanAirCapable"),  # enum{No, Yes}
	("String", "cleanAirSensorStatus"),  # enum{Down, NA, Up}
	("String", "cleanAirStatus"), 	# enum{No, Yes}
	("String", "clientCount"),
	("String", "controllerIpAddress"),
	("boolean", "dot11nCapable"), 	# enum{TRUE, FALSE}
	("String", "ethernetMac"), 		# MAC
	("String", "instanceUuid"),
	("RadioOperStatusEnum", "operStatus"),
	("int", "port"), 				# controller port number
	("int", "powerLevel"), 			# [0:8]
	("RadioRoleEnum", "radioRole"),
	("String", "radioType"), 		# enum{"801.11[a|a/n|a/n/ac|b/g|b/g/n]"}
	("int", "slotId"), 				# [0:1]
	("String", "txPowerControl") 	# enum{Automatic, Custom}
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(archive, Table("v2", "data", "WlanProfiles", True, DAY+offset, 1000,
	("String", "@id"),
	("String", "@displayName", False),  # dupl @id uncommented 2018-07-01
	("boolean", "aaaAllowOverride"),  # allow AAA override?
	("String", "aaaLdapPrimaryServer"),  # 1st LDAP server
	("String", "aaaLdapSecondaryServer"),  # 2nd LDAP server
	("String", "aaaLdapTertiaryServer"),  # 3rd LDAP server
	("boolean", "aaaLocalEapAuthenticationEnabled"),  # local EAP auth?
	("boolean", "aaaLocalEapAuthenticationProfileName"),  # if so, the profile
	("String", "aaaRadiusAccountingPrimaryServer"),  # The 1st, when aaaRadiusAccountingServersEnabled
	("String", "aaaRadiusAccountingSecondaryServer"),  # The 2nd, when aaaRadiusAccountingSeversEnabled
	("boolean", "aaaRadiusAccountingServersEnabled"),  # RADIUS accounting?
	("String", "aaaRadiusAccountingTertiaryServer"),  # The 3rd, when aaaRadiusAccountingSeversEnabled
	("String", "aaaRadiusAuthenticationPrimaryServer"),  # The 1st, when aaaRadiusAuthorizationServersEnabled
	("String", "aaaRadiusAuthenticationSecondaryServer"),  # The 2nd, when aaaRadiusAuthorizationServersEnabled
	("boolean", "aaaRadiusAuthenticationServersEnabled"),  # RADIUS authorization?
	("String", "aaaLocalEapAuthenticationProfileName"),  # ... if so, the EAP profile to use
	("String", "aaaRadiusAuthenticationTertiaryServer"),  # The 3rd, when aaaRadiusAuthorizationServersEnabled
	("boolean", "aaaRadiusInterimUpdateEnabled"),  # RADIUS server accounting interim update?
	("long", "aaaRadiusInterimUpdateInterval"),  # ... if so, the update interval in seconds
	("boolean", "adminStatus"), 	# WLAN administratively enabled?
	("boolean", "advancedAironetIeEnabled"),  # Aironet Info Elements enabled for this WLAN?
	("boolean", "advancedClientExclusionEnabled"),  # auto client exclusion?
	("long", "advancedClientExclusionTimeout"),  # ... if so, tieout in seconds or 0 for infinite
	("boolean", "advancedCoverageHoleDetectionEnabled"),  # coverage hole detection?
	("boolean", "advancedDhcpAddressAssignmentRequired"),  # each client required to obtain IP address via DHCP?
	("boolean", "advancedDhcpProfilingEnabled"),  # should the controller collect DHCP attribtes of clients on this WLAN?
	("String", "advancedDhcpServerIpAddress_address"),  # if valid, an IPv4 DHCP server specified for this WLAN
	("boolean", "advancedDiagnosticChannelEnabled"),  # diagnostic channel available for this WLAN?
	("long", "advancedDot11anDtimPeriod"),  # Delivery Traffic Indication Map (DTIM) for 802.11a/n
	# measured in beacons, during which broadcast and multicast frames will be transmitted.
	("long", "advancedDot11bgnDtimPeriod"),  # DTIM interval for 802.11b/g/n
	("boolean", "advancedFlexConnectCentralDhcpProcessingEnabled"),
	("boolean", "advancedFlexConnectLearnClientIpEnabled"),
	("boolean", "advancedFlexConnectLocalAuthEnabled"),
	("boolean", "advancedFlexConnectLocalSwitchingEnabled"),
	("boolean", "advancedFlexConnectNatPatEnabled"),
	("boolean", "advancedFlexConnectOverrideDnsEnabled"),
	("boolean", "advancedFlexConnectReapCentralAssociation"),
	("boolean", "advancedFlexConnectVlanCentralSwitchingEnabled"),
	("boolean", "advancedHttpProfilingEnabled"),
	("boolean", "advancedIpv6Enabled"),
	("boolean", "advancedKtsCacEnabled"),
	("boolean", "advancedLoadBalancingBandSelectEnabled"),
	("boolean", "advancedLoadBalancingEnabled"),
	("long", "advancedMaximumClients"),
	("String", "advancedMdnsProfileName"),
	("boolean", "advancedMdnsSnoopingEnabled"),
	("boolean", "advancedMediaSessionSnoopingEnabled"),
	("DisabledEnabledRequiredEnum", "advancedMfpClientProtection"),
	("boolean", "advancedMfpSignatureGenerationEnabled"),
	("long", "advancedMfpVersion"),
	("String", "advancedOverrideInterfaceAclName"),
	("String", "advancedOverrideInterfaceIpv6AclName"),
	("boolean", "advancedPassiveClientEnabled"),
	("Peer2PeerBlockingEnum", "advancedPeerToPeerBlocking"),
	("PmipMobilityTypeEnum", "advancedPmipMobilityType"),
	("String", "advancedPmipProfile"),
	("String", "advancedPmipRealm"),
	("boolean", "advancedScanDeferPriority0"),
	("boolean", "advancedScanDeferPriority1"),
	("boolean", "advancedScanDeferPriority2"),
	("boolean", "advancedScanDeferPriority3"),
	("boolean", "advancedScanDeferPriority4"),
	("boolean", "advancedScanDeferPriority5"),
	("boolean", "advancedScanDeferPriority6"),
	("boolean", "advancedScanDeferPriority7"),
	("long", "advancedScanDeferTime"),
	("long", "advancedSessionTimeout"),
	("DisabledAllowedNotAllowedEnum", "advancedWifiDirectClientsPolicy"),
	("boolean", "broadcastSsidEnabled"),
	("long", "ckipKeyIndex"),
	("boolean", "ckipKeyPermutationEnabled"),
	("CkipEncryptionTypeEnum", "ckipKeySize"),
	("boolean", "ckipMmhModeEnabled"),
	("boolean", "ckipSecurityEnabled"),
	("long", "controllerId"),
	("boolean", "hotspot2Enable_hotSpot2Enabled"),
	("long", "hotspot2Wan_downLinkSpeed"),
	("long", "hotspot2Wan_upLinkSpeed"),
	("String", "hotspot2Wan_wanLinkStatus"),
	("String", "hotspot2Wan_wanSymLinkStatus"),
	("String", "hotspotGeneral_heSsid_octets"),
	("boolean", "hotspotGeneral_internetAccess"),
	("String", "hotspotGeneral_ipv4AddressAvailType"),
	("String", "hotspotGeneral_ipv6AddressAvailType"),
	("String", "hotspotGeneral_networkAuthType"),
	("String", "hotspotGeneral_networkType"),
	("boolean", "hotspotGeneral_status"),
	("boolean", "hotspotServiceAdvertisement_msapEnable"),
	("long", "hotspotServiceAdvertisement_serverIndex"),
	# We don't have hotspots. Ignore the embedded array in relational model
	# hotspotOperatorConfigTemplate[]
	# hotspotPortConfigTemplate
	# hotspotGppConfigTemplate[]
	# hotspotDomainConnfigTemplat[]
	#
	# ("String", "instanceUuid"),
	("String", "interfaceName"),
	("InterfaceMappingTypeEnum", "interfaceType"),
	("String", "ipAddress", False),  # appeared in 3.6
	("boolean", "isWiredLan"),
	("LanTypeEnum", "lanType"),
	("boolean", "layer2FastTransitionEnabled"),
	("boolean", "layer2FastTransitionOverDsEnabled"),
	("long", "layer2FastTransitionReassociationTimeout"),
	("boolean", "layer2MacFilteringEnabled"),
	("boolean", "layer3GlobalWebAuthEnabled"),
	("String", "layer3PreauthenticationAcl"),
	("String", "layer3PreauthenticationIpv6Acl"),
	("boolean", "layer3VpnPassthroughEnabled"),
	("String", "layer3WebAuthFlexAcl"),
	("WlanWebAuthTypeEnum", "layer3WebAuthType"),
	("boolean", "layer3WebPolicyAuthenticationEnabled"),
	("boolean", "layer3WebPolicyConditionalRedirectEnabled"),
	("boolean", "layer3WebPolicyOnMacFailureEnabled"),
	("boolean", "layer3WebPolicyPassthroughEnabled"),
	("boolean", "multicastVlanEnabled"),
	("String", "multicastVlanInterface"),
	("String", "profileName"),
	("PhoneSupport7920Enum", "qos7920Cac"),
	("String", "qosAvcProfileName"),
	("boolean", "qosNbarVisibilityEnabled"),
	("String", "qosNetflowMonitor"),
	("long", "qosPerSSidBurstRealTimeUpstreamRate"),
	("long", "qosPerSsidAverageDownstreamRate"),
	("long", "qosPerSsidAverageRealTimeDownstreamRate"),
	("long", "qosPerSsidAverageRealTimeUpstreamRate"),
	("long", "qosPerSsidAverageUpstreamRate"),
	("long", "qosPerSsidBurstDownstreamRate"),
	("long", "qosPerSsidBurstRealTimeDownstreamRate"),
	("long", "qosPerSsidBurstUpstreamRate"),
	("long", "qosPerUserAverageDownstreamRate"),
	("long", "qosPerUserAverageRealTimeDownstreamRate"),
	("long", "qosPerUserAverageRealTimeUpstreamRate"),
	("long", "qosPerUserAverageUpstreamRate"),
	("long", "qosPerUserBurstDownstreamRate"),
	("long", "qosPerUserBurstRealTimeDownstreamRate"),
	("long", "qosPerUserBurstRealTimeUpstreamRate"),
	("long", "qosPerUserBurstUpstreamRate"),
	("QosEnum", "qosProfile"),
	("DisabledAllowedRequiredEnum", "qosWmmPolicy"),
	("RadioPolicyEnum", "radioPolicy"),
	("String", "ssid"),
	("String", "vpnPassThroughGatewayAddress_address"),
	("String", "webAuthExternalUrl"),
	("String", "webAuthLoginFailurePage"),
	("String", "wwebAuthLoginPage"),
	("String", "webAuthLogoutPage"),
	("boolean", "webPassthruEmailInputEnabled"),
	("boolean", "wepAllowSharedKeyAuthentication"),
	("long", "wepKeyIndex"),
	("WepEncryptionTypeEnum", "wepKeySize"),
	("boolean", "wepSecurityEnabled"),
	("long", "wlanId"),
	("boolean", "wpa2Enabled"),
	("boolean", "wpa2EncryptionProtocolAes"),
	("boolean", "wpa2EncryptionProtocolTkip"),
	("boolean", "wpaAuthenticationKeyManagement8021x"),
	("boolean", "wpaAuthenticationKeyManagementCckm"),
	("boolean", "wpaAuthenticationKeyManagementFt8021x"),
	("boolean", "wpaAuthenticationKeyManagementFtPsk"),
	("boolean", "wpaAuthenticationKeyManagementPmf8021x"),
	("boolean", "wpaAuthenticationKeyManagementPmfPsk"),
	("boolean", "wpaAuthenticationKeyManagementPsk"),
	("boolean", "wpaEnabled"),
	("boolean", "wpaEncryptionProtocolAes"),
	("boolean", "wpaEncryptionProtocolTkip"),
	("PskFormatEnum", "wpaPresharedKey", False),  # appeared in 3.6
	("String", "wpaPresharedKeyFormat", False),  # appeared in 3.6
	("boolean", "wpaSecurityEnabled"),
	("x8021EncryptionTypeEnum", "x8021KeySize"),
	("boolean", "x8021SecurityEnabled")
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

offset += 5*60.0
add_table(archive, Table("v1", "data", "WlanProfiles", True, DAY+offset, 1000,
	("String", "@id"),
	("String", "@displayName"), 	# duplicates @id
	("boolean", "aaaAllowOverride"),  # is allow AAA override enabled?
	("String", "aaaLdapPrimaryServer"),  # 1st LDAP server
	("String", "aaaLdapSecondaryServer"),  # 2nd LDAP server
	("String", "aaaLdapTertiaryServer"),  # 3rd LDAP server
	("boolean", "aaaLocalEapAuthenticationEnabled"),  # local EAP authentication?
	("boolean", "aaaLocalEapAuthenticationProfileName"),  # if so, the profile
	("String", "aaaRadiusAccountingPrimaryServer"),  # The 1st, when aaaRadiusAccountingServersEnabled
	("String", "aaaRadiusAccountingSecondaryServer"),  # The 2nd, when aaaRadiusAccountingServersEnabled
	("boolean", "aaaRadiusAccountingServersEnabled"),  # RADIUS accounting?
	("String", "aaaRadiusAccountingTertiaryServer"),  # The 3rd, when aaaRadiusAccountingServersEnabled
	("String", "aaaRadiusAuthenticationPrimaryServer"),  # The 1st, when aaaRadiusAuthorizationServersEnabled
	("String", "aaaRadiusAuthenticationSecondaryServer"),  # The 2nd, when aaaRadiusAuthorizationServersEnabled
	("boolean", "aaaRadiusAuthenticationServersEnabled"),  # RADIUS authorization?
	("String", "aaaLocalEapAuthenticationProfileName"),  # if so, the profile
	("String", "aaaRadiusAuthenticationTertiaryServer"),  # The tertiary, when aaaRadiusAuthorizationServersEnabled
	("boolean", "aaaRadiusInterimUpdateEnabled"),  # RADIUS server accounting interim update?
	("long", "aaaRadiusInterimUpdateInterval"),  # if so, the update interval in seconds
	("boolean", "adminStatus"), 	# WLAN administratively enabled?
	("boolean", "advancedAironetIeEnabled"),  # Aironet Info Elements enabled for this WLAN?
	("boolean", "advancedClientExclusionEnabled"),  # auto client exclusion?
	("long", "advancedClientExclusionTimeout"),  # ... if so, timeout in seconds or 0 for infinite
	("boolean", "advancedCoverageHoleDetectionEnabled"),  # coverage hole detection?
	("boolean", "advancedDhcpAddressAssignmentRequired"),  # each client required to obtain IP address via DHCP?
	("boolean", "advancedDhcpProfilingEnabled"),  # should the controller collect DHCP attribtes of clients on this WLAN?
	("String", "advancedDhcpServerIpAddress_address"),  # if valid, an IPv4 DHCP server specified for this WLAN
	("boolean", "advancedDiagnosticChannelEnabled"),  # diagnostic channel available for this WLAN?
	("long", "advancedDot11anDtimPeriod"),  # Delivery Traffic Indication Map (DTIM) for 802.11a/n
	# measured in beacons, during which broadcast and multicast frames will be transmitted.
	("long", "advancedDot11bgnDtimPeriod"),  # DTIM interval for 802.11b/g/n
	("boolean", "advancedFlexConnectCentralDhcpProcessingEnabled"),  #
	("boolean", "advancedFlexConnectLearnClientIpEnabled"),
	("boolean", "advancedFlexConnectLocalAuthEnabled"),
	("boolean", "advancedFlexConnectLocalSwitchingEnabled"),
	("boolean", "advancedFlexConnectNatPatEnabled"),
	("boolean", "advancedFlexConnectOverrideDnsEnabled"),
	("boolean", "advancedFlexConnectReapCentralAssociation"),
	("boolean", "advancedFlexConnectVlanCentralSwitchingEnabled"),
	("boolean", "advancedHttpProfilingEnabled"),
	("boolean", "advancedIpv6Enabled"),
	("boolean", "advancedKtsCacEnabled"),
	("boolean", "advancedLoadBalancingBandSelectEnabled"),
	("boolean", "advancedLoadBalancingEnabled"),
	("long", "advancedMaximumClients"),
	("String", "advancedMdnsProfileName"),
	("boolean", "advancedMdnsSnoopingEnabled"),
	("boolean", "advancedMediaSessionSnoopingEnabled"),
	("DisabledEnabledRequiredEnum", "advancedMfpClientProtection"),
	("boolean", "advancedMfpSignatureGenerationEnabled"),
	("long", "advancedMfpVersion"),
	("String", "advancedOverrideInterfaceAclName"),
	("String", "advancedOverrideInterfaceIpv6AclName"),
	("boolean", "advancedPassiveClientEnabled"),
	("Peer2PeerBlockingEnum", "advancedPeerToPeerBlocking"),
	("PmipMobilityTypeEnum", "advancedPmipMobilityType"),
	("String", "advancedPmipProfile"),
	("String", "advancedPmipRealm"),
	("boolean", "advancedScanDeferPriority0"),
	("boolean", "advancedScanDeferPriority1"),
	("boolean", "advancedScanDeferPriority2"),
	("boolean", "advancedScanDeferPriority3"),
	("boolean", "advancedScanDeferPriority4"),
	("boolean", "advancedScanDeferPriority5"),
	("boolean", "advancedScanDeferPriority6"),
	("boolean", "advancedScanDeferPriority7"),
	("long", "advancedScanDeferTime"),
	("long", "advancedSessionTimeout"),
	("DisabledAllowedNotAllowedEnum", "advancedWifiDirectClientsPolicy"),
	("boolean", "broadcastSsidEnabled"),
	("long", "ckipKeyIndex"),
	("boolean", "ckipKeyPermutationEnabled"),
	("CkipEncryptionTypeEnum", "ckipKeySize"),
	("boolean", "ckipMmhModeEnabled"),
	("boolean", "ckipSecurityEnabled"),
	("long", "controllerId"),
	("boolean", "hotspot2Enable_hotSpot2Enabled"),
	("long", "hotspot2Wan_downLinkSpeed"),
	("long", "hotspot2Wan_upLinkSpeed"),
	("String", "hotspot2Wan_wanLinkStatus"),
	("String", "hotspot2Wan_wanSymLinkStatus"),
	("String", "hotspotGeneral_heSsid_octets"),
	("boolean", "hotspotGeneral_internetAccess"),
	("String", "hotspotGeneral_ipv4AddressAvailType"),
	("String", "hotspotGeneral_ipv6AddressAvailType"),
	("String", "hotspotGeneral_networkAuthType"),
	("String", "hotspotGeneral_networkType"),
	("boolean", "hotspotGeneral_status"),
	("boolean", "hotspotServiceAdvertisement_msapEnable"),
	("long", "hotspotServiceAdvertisement_serverIndex"),
	# We don't have hotspots. Ignore the embedded array in relational model
	# hotspotOperatorConfigTemplate[]
	# hotspotPortConfigTemplate
	# hotspotGppConfigTemplate[]
	# hotspotDomainConnfigTemplat[]
	#
	("String", "instanceUuid"),
	("String", "interfaceName"),
	("InterfaceMappingTypeEnum", "interfaceType"),
	("boolean", "isWiredLan"),
	("LanTypeEnum", "lanType"),
	("boolean", "layer2FastTransitionEnabled"),
	("boolean", "layer2FastTransitionOverDsEnabled"),
	("long", "layer2FastTransitionReassociationTimeout"),
	("boolean", "layer2MacFilteringEnabled"),
	("boolean", "layer3GlobalWebAuthEnabled"),
	("String", "layer3PreauthenticationAcl"),
	("String", "layer3PreauthenticationIpv6Acl"),
	("boolean", "layer3VpnPassthroughEnabled"),
	("String", "layer3WebAuthFlexAcl"),
	("WlanWebAuthTypeEnum", "layer3WebAuthType"),
	("boolean", "layer3WebPolicyAuthenticationEnabled"),
	("boolean", "layer3WebPolicyConditionalRedirectEnabled"),
	("boolean", "layer3WebPolicyOnMacFailureEnabled"),
	("boolean", "layer3WebPolicyPassthroughEnabled"),
	("boolean", "multicastVlanEnabled"),
	("String", "multicastVlanInterface"),
	("String", "profileName"),
	("PhoneSupport7920Enum", "qos7920Cac"),
	("String", "qosAvcProfileName"),
	("boolean", "qosNbarVisibilityEnabled"),
	("String", "qosNetflowMonitor"),
	("long", "qosPerSSidBurstRealTimeUpstreamRate"),
	("long", "qosPerSsidAverageDownstreamRate"),
	("long", "qosPerSsidAverageRealTimeDownstreamRate"),
	("long", "qosPerSsidAverageRealTimeUpstreamRate"),
	("long", "qosPerSsidAverageUpstreamRate"),
	("long", "qosPerSsidBurstDownstreamRate"),
	("long", "qosPerSsidBurstRealTimeDownstreamRate"),
	("long", "qosPerSsidBurstUpstreamRate"),
	("long", "qosPerUserAverageDownstreamRate"),
	("long", "qosPerUserAverageRealTimeDownstreamRate"),
	("long", "qosPerUserAverageRealTimeUpstreamRate"),
	("long", "qosPerUserAverageUpstreamRate"),
	("long", "qosPerUserBurstDownstreamRate"),
	("long", "qosPerUserBurstRealTimeDownstreamRate"),
	("long", "qosPerUserBurstRealTimeUpstreamRate"),
	("long", "qosPerUserBurstUpstreamRate"),
	("QosEnum", "qosProfile"),
	("DisabledAllowedRequiredEnum", "qosWmmPolicy"),
	("RadioPolicyEnum", "radioPolicy"),
	("String", "ssid"),
	("String", "vpnPassThroughGatewayAddress_address"),
	("String", "webAuthExternalUrl"),
	("String", "webAuthLoginFailurePage"),
	("String", "wwebAuthLoginPage"),
	("String", "webAuthLogoutPage"),
	("boolean", "webPassthruEmailInputEnabled"),
	("boolean", "wepAllowSharedKeyAuthentication"),
	("long", "wepKeyIndex"),
	("WepEncryptionTypeEnum", "wepKeySize"),
	("boolean", "wepSecurityEnabled"),
	("long", "wlanId"),
	("boolean", "wpa2Enabled"),
	("boolean", "wpa2EncryptionProtocolAes"),
	("boolean", "wpa2EncryptionProtocolTkip"),
	("boolean", "wpaAuthenticationKeyManagement8021x"),
	("boolean", "wpaAuthenticationKeyManagementCckm"),
	("boolean", "wpaAuthenticationKeyManagementFt8021x"),
	("boolean", "wpaAuthenticationKeyManagementFtPsk"),
	("boolean", "wpaAuthenticationKeyManagementPmf8021x"),
	("boolean", "wpaAuthenticationKeyManagementPmfPsk"),
	("boolean", "wpaAuthenticationKeyManagementPsk"),
	("boolean", "wpaEnabled"),
	("boolean", "wpaEncryptionProtocolAes"),
	("boolean", "wpaEncryptionProtocolTkip"),
	("boolean", "wpaSecurityEnabled"),
	("x8021EncryptionTypeEnum", "x8021KeySize"),
	("boolean", "x8021SecurityEnabled")
	).set_id_field("@id")
	.set_query_options({".full": "true", ".nocount": "true"})
)

add_table(test, Table("v1", "data", "people", True, DAY+offset, 1000,
	('int', 'id'),
	('String', 'first'),
	('String', 'last'),
	('String', 'notes')
	).set_id_field('id')
)

if __name__ == '__main__':			# test
	report_type_uses(1) 			# report each type not used in a field definition
	print(f"NUMHIST={NUMHIST}")
